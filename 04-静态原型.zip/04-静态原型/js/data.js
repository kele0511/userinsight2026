/* 易小助高保真原型 · Mock 数据（与 PRD 10.5 对齐，日期锚定 2026-08-24） */
window.HXZ = window.HXZ || {};

HXZ.TODAY = "2026-08-24";
HXZ.TODAY_LABEL = "2026.08.24 周一";
HXZ.RM = { name: "李明", id: "RM001" };

HXZ.CUSTOMERS = [
  {
    id: "100017",
    name: "王芳",
    age: 36,
    gender: "女",
    job: "企业主",
    phone: "138****8017",
    industry: "批发零售",
    city: "杭州市常住",
    edu: "本科",
    tags: ["高净值关注", "定投用户"],
    risk: "稳健型",
    riskStatus: "valid",
    level: "普通",
    aum: 50000,
    wealthScore: 72,
    wealthScoreDate: "2026-08-01",
    family: "已婚 | 已育 | 子女处于基础教育阶段",
    biz: {
      name: "杭州市芳华商贸有限公司",
      years: "6年",
      share: "80%",
      capital: "100.0000万",
      addr: "杭州市西湖区",
      scope: "日用百货批发",
      continuity: "近三个月我行对公户交易对手含有「货款、结算款、采购、预付款」"
    },
    cash: {
      inAmt: "3,000,000.00",
      inDesc: "资金来源为每月月底上游结算款项，但资金流入后当月100%同名转出，无留存。",
      outAmt: "1,800,000.00",
      outDesc: "出金分布主要为转账、教育支出、餐饮美食"
    },
    holding: {
      total: 347028,
      pnl: 7896.39,
      annual: "2.94%",
      peak: "34.7万（8月）",
      slices: [
        { k: "存款", v: 35000, c: "#E6002D" },
        { k: "理财", v: 200671, c: "#7B61FF" },
        { k: "基金", v: 146297, c: "#3768FA" },
        { k: "贵金属", v: 9549, c: "#5B8DEF" },
        { k: "其他", v: 1000, c: "#2BA471" }
      ]
    },
    credit: {
      count: 2,
      bal: "128,000.00",
      loans: [
        { name: "经营周转贷A", limit: "200,000.00", used: "80,000.00", left: "120,000.00", overdue: 1 },
        { name: "消费信用贷B", limit: "50,000.00", used: "48,000.00", left: "2,000.00", overdue: 0 }
      ],
      reject: { name: "房屋按揭贷款", reason: "负债收入比超限", date: "2025-11-02" },
      gjj: "8,500.00（2026年07月）",
      sb: "7,200.00（2026年07月）"
    },
    behavior: {
      finance: "近30天高频访问手机银行理财频道，有在线咨询贵金属如何购买，推测偏好理财、贵金属。建议推荐理财、贵金属大类。",
      liquidity: "客户偏好短期（1个月以内）的金融产品",
      risk: "行内已完成风险评测，结果为稳健型。近180天浏览产品风险等级主要集中在基金，表明其有意愿承担较高波动以追求资产增值。",
      market: "偏好电销渠道，近3个月参与过1次营销活动，推荐新年赢红包活动。建议营销时间为上午9–11点。",
      payroll: "当月代发工资总额 0.00 元，最近一次代发日期 2026-08-10。近6月月均代发 50,000.00 元，最高月 62,000.00 元（2026年03月）。薪资水平等级中等，工资3日留存度 12%，7日留存度 8%。",
      other: "近期沟通记录显示有财富产品意向。"
    }
  },
  {
    id: "100018",
    name: "王磊",
    age: 44,
    gender: "男",
    job: "高管",
    phone: "139****6621",
    industry: "金融业",
    city: "合肥市常住",
    edu: "硕士",
    tags: ["代发客群"],
    risk: "稳健型",
    riskStatus: "expired",
    level: "财富(20-50万)",
    aum: 286000,
    wealthScore: 81,
    wealthScoreDate: "2026-07-12",
    family: "已婚 | 已育 | 子女处于高等教育阶段",
    biz: null,
    cash: { inAmt: "860,000.00", inDesc: "主要为工资代发及年终奖。", outAmt: "420,000.00", outDesc: "房贷、教育、日常消费" },
    holding: {
      total: 286000,
      pnl: 4320.12,
      annual: "2.11%",
      peak: "31.2万（6月）",
      slices: [
        { k: "存款", v: 120000, c: "#E6002D" },
        { k: "理财", v: 110000, c: "#7B61FF" },
        { k: "基金", v: 56000, c: "#3768FA" }
      ]
    },
    credit: { count: 1, bal: "32,000.00", loans: [{ name: "信用消费贷", limit: "80,000.00", used: "32,000.00", left: "48,000.00", overdue: 0 }], reject: null, gjj: "12,000.00（2026年07月）", sb: "10,800.00（2026年07月）" },
    behavior: {
      finance: "偏好稳健理财，近30天浏览债券型基金较多。",
      liquidity: "中短期（1–3月）",
      risk: "风测已过期，近180天仍在浏览 R2–R3 产品。",
      market: "偏好短信渠道，建议晚间 19–21 点。",
      payroll: "当月代发 28,600.00 元，代发日期 2026-08-08。",
      other: "有贷款意向。"
    }
  },
  {
    id: "100019",
    name: "赵毅民",
    age: 61,
    gender: "男",
    job: "退休",
    phone: "137****0933",
    industry: "其他",
    city: "芜湖市常住",
    edu: "高中",
    tags: [],
    risk: "",
    riskStatus: "none",
    level: "万元户",
    aum: 42000,
    wealthScore: 41,
    wealthScoreDate: "2026-06-20",
    family: "已婚 | 子女已独立",
    biz: null,
    cash: { inAmt: "96,000.00", inDesc: "养老金及子女转账。", outAmt: "54,000.00", outDesc: "生活支出、医疗" },
    holding: {
      total: 42000,
      pnl: 610.00,
      annual: "1.82%",
      peak: "4.5万（5月）",
      slices: [
        { k: "存款", v: 30000, c: "#E6002D" },
        { k: "理财", v: 12000, c: "#7B61FF" }
      ]
    },
    credit: null,
    behavior: {
      finance: "偏好存款及低风险理财。",
      liquidity: "短期（0–1月）",
      risk: "未完成风险测评。",
      market: "偏好电话，上午 9–11 点。",
      payroll: "无代发。",
      other: ""
    }
  }
];

HXZ.PRODUCTS = {
  wm: [
    {
      id: "AXLCSH20253001",
      name: "「安盈」稳利1年固定收益类理财产品",
      code: "AXLCSH20253001",
      type: "wm",
      cat: "固定期限",
      termType: "固定期限",
      yield: "3.56%",
      yieldType: "成立以来年化",
      yieldDesc: "成立以来年化收益率，按产品净值计算，过往业绩不代表未来表现。",
      rules: "最短持有180天",
      minAmt: "100.00元",
      risk: "R2",
      riskLabel: "R2中低风险",
      status: "开放期",
      star: true,
      currency: "人民币",
      org: "安鑫理财",
      found: "2025-11-12",
      openType: "最小持有期型",
      bench: "1.20%–3.40%",
      confirm: "交易日17:00前买入，T+2个交易日确认",
      redeemArrive: "T+3个交易日到账",
      invest: ["固定收益类不低于：60%", "权益类资产与衍生金融工具（以保证金计）：20%–40%", "其中衍生金融工具（以保证金计）：0%–5%"],
      perf: [
        { p: "近1月", chg: "0.49%", ann: "5.26%" },
        { p: "近3月", chg: "0.81%", ann: "3.28%" },
        { p: "近6月", chg: "1.94%", ann: "3.91%" },
        { p: "近1年", chg: "2.64%", ann: "2.64%" },
        { p: "成立以来", chg: "3.56%", ann: "3.56%" }
      ]
    },
    {
      id: "SYLC20253005",
      name: "苏银理财恒源1年5期",
      code: "SYLC20253005",
      type: "wm",
      cat: "固定期限",
      termType: "固定期限",
      yield: "5.71%",
      yieldType: "成立以来年化",
      yieldDesc: "成立以来年化收益率，过往业绩不代表未来表现。",
      rules: "最短持有90天",
      minAmt: "1.00元",
      risk: "R3",
      riskLabel: "R3中风险",
      status: "开放期",
      star: true,
      currency: "人民币",
      org: "苏银理财",
      found: "2026-03-03",
      openType: "最小持有期型",
      bench: "2.10%–4.80%",
      confirm: "交易日17:00前买入，T+2个交易日确认",
      redeemArrive: "T+2个交易日到账",
      invest: ["固收+可转债及黄金增强", "权益仓位弹性更高"],
      perf: [
        { p: "近1月", chg: "0.62%", ann: "7.41%" },
        { p: "近3月", chg: "1.20%", ann: "4.88%" },
        { p: "近6月", chg: "2.41%", ann: "4.86%" },
        { p: "近1年", chg: "5.71%", ann: "5.71%" },
        { p: "成立以来", chg: "5.71%", ann: "5.71%" }
      ]
    },
    {
      id: "RTLY60",
      name: "日添利现金管理类理财产品60号",
      code: "RTLY0060",
      type: "wm",
      cat: "活钱理财",
      termType: "无固定期限",
      yield: "1.6640%",
      yieldType: "近7日年化",
      yieldDesc: "7日年化收益率(%) = {[Π(1+Ri/10000)]^(365/7)−1}×100",
      rules: "灵活期限 | 人民币",
      minAmt: "0.01元",
      risk: "R1",
      riskLabel: "R1低风险",
      status: "开放期",
      star: true,
      currency: "人民币",
      org: "安鑫理财",
      found: "2024-03-18",
      cashLike: true,
      confirm: "交易日17:00前买入，T+1个交易日确认",
      redeemArrive: "T+1个交易日到账",
      invest: ["现金及货币市场工具为主"],
      perf: [
        { p: "近7日", chg: "1.6640%", ann: "—" },
        { p: "近1月", chg: "1.7021%", ann: "—" }
      ]
    }
  ],
  fund: [
    {
      id: "F000001",
      name: "西部利得祥盈债券型证券投资基金A类",
      code: "675091",
      type: "fund",
      klass: "债券型",
      klass2: "中长期纯债",
      monetary: false,
      yield: "8.4500%",
      yieldType: "近1年收益率",
      nav: "1.1973",
      daily: "0.1200%",
      date: "2026-08-22",
      minAmt: "1.00元",
      risk: "R3",
      riskLabel: "R3中风险",
      company: "西部利得基金",
      trustee: "招商银行",
      found: "2019-04-16",
      status: "开放申赎",
      agency: true
    },
    {
      id: "F000002",
      name: "天弘余额宝货币市场基金",
      code: "000198",
      type: "fund",
      klass: "货币型",
      klass2: "货币型",
      monetary: true,
      yield: "1.1435%",
      yieldType: "近7日年化",
      wanfen: "0.1887",
      date: "2026-08-22",
      minAmt: "0.01元",
      risk: "R1",
      riskLabel: "R1低风险",
      company: "天弘基金",
      trustee: "中信银行",
      found: "2013-05-29",
      status: "开放申赎",
      agency: true
    },
    {
      id: "F000003",
      name: "天弘富时自由现金流指数A",
      code: "021413",
      type: "fund",
      klass: "股票型",
      klass2: "指数型",
      monetary: false,
      yield: "-0.3600%",
      yieldType: "日涨幅",
      nav: "1.0264",
      daily: "-0.3600%",
      date: "2026-08-22",
      minAmt: "1.00元",
      risk: "R4",
      riskLabel: "R4中高风险",
      company: "天弘基金",
      trustee: "华夏银行",
      found: "2024-09-01",
      status: "开放申赎",
      agency: true
    }
  ],
  ins: [
    {
      id: "I000001",
      name: "阳光人寿金吉利G款两全保险",
      code: "YGJJG",
      type: "ins",
      cat: "寿险",
      company: "阳光人寿",
      attr: "人寿",
      payType: "年缴",
      payYears: "3年",
      coverType: "年保",
      coverYears: "10年",
      subtitle: "保10年 3年缴",
      premium: "500.00元起",
      risk: "R2",
      riskLabel: "R2中低风险"
    },
    {
      id: "I000002",
      name: "中国人寿臻享传家终身寿险",
      code: "RSZXCJ",
      type: "ins",
      cat: "寿险",
      company: "中国人寿",
      attr: "人寿",
      payType: "年缴",
      payYears: "10年",
      coverType: "终身",
      coverYears: "终身",
      subtitle: "终身保障 10年缴",
      premium: "500.00元起",
      risk: "R2",
      riskLabel: "R2中低风险"
    },
    {
      id: "I000003",
      name: "太平洋鑫如意年金保险",
      code: "TPXYR",
      type: "ins",
      cat: "寿险",
      company: "太平洋保险",
      attr: "人寿",
      payType: "趸缴",
      payYears: "趸缴",
      coverType: "年保",
      coverYears: "15年",
      subtitle: "保15年 趸缴",
      premium: "1,000.00元起",
      risk: "R3",
      riskLabel: "R3中风险"
    }
  ],
  deposit: [
    { id: "DP000017", name: "普惠金融存单1年期", tag: "大额存单", rate: "1.90%", term: "1年", minAmt: "20,000.00元" },
    { id: "D001", name: "一个月通知存款", tag: "通知存款", rate: "2.404%", term: "灵活期限", minAmt: "10,000.00元" },
    { id: "D002", name: "三个月定期存款", tag: "定期存款", rate: "2.404%", term: "35天", minAmt: "10,000.00元" },
    { id: "D003", name: "添金喜个人结构性存款25213期（人民币）", tag: "结构性存款", rate: "2.059–2.65%", term: "3年封闭", minAmt: "10,000.00元" }
  ]
};

HXZ.RIGHTS = [
  { id: "R1", name: "贵宾机场休息室", desc: "本季度可使用 2 次国内机场贵宾厅，需提前 2 小时预约。", period: "2026-02-09至2026-12-09" },
  { id: "R2", name: "生日专属积分加倍", desc: "生日当月积分消费享 2 倍加速，封顶 5000 分。", period: "2026-01-01至2026-12-31" }
];

HXZ.ACTIVITIES = [
  { id: "A1", name: "新发卡理财组合包", desc: "面向近30天新发卡客户，理财组合包 100 元起投，8.9 折，可联动配置基金。登录手机银行-理财页参与。", period: "2026-08-05至2026-08-30" },
  { id: "A2", name: "新年赢红包", desc: "资产达标客户可抽最高 88 元红包，活动期内限参与 1 次。", period: "2026-08-01至2026-09-15" }
];

HXZ.TODOS = {
  expire: [
    { id: "t-e1", custId: "100017", handled: false, products: [{ name: "整存整取三年期", amt: "50,000.00元", date: "2026.08.28" }] },
    { id: "t-e2", custId: "100019", handled: false, products: [
      { name: "整存整取三年期", amt: "20,000.00元", date: "2026.09.01" },
      { name: "安鑫理财悦享周期", amt: "12,000.00元", date: "2026.09.03" }
    ]}
  ],
  move: [
    { id: "t-m1", custId: "100017", handled: false, bal: "50,000.00元", delta: 50000 },
    { id: "t-m2", custId: "100018", handled: false, bal: "286,000.00元", delta: -50000 }
  ],
  loan: [
    { id: "t-l1", custId: "100017", handled: false, name: "经营周转贷A", overdueAmt: "3,190.09元", times: "12/36", due: "8月20日", days: 4 }
  ],
  birthday: [
    { id: "t-b1", custId: "100017", handled: false, birth: "1989.09.09", left: 16 },
    { id: "t-b2", custId: "100018", handled: true, birth: "1982.08.26", left: 2 }
  ],
  contact: [
    { id: "t-c1", custId: "100017", aum: "50,000.00元", last: "8月10日", days: 14 }
  ],
  card: [
    { id: "t-k1", custId: "100017", handled: false, acct: "6214 2312 4212 4441", biz: "信用卡年费收取" }
  ]
};

HXZ.YDAY = {
  rate: "78.98%",
  rows: [
    { k: "产品到期", done: 4, total: 20, restHint: "跟进" },
    { k: "上日大额异动", done: 8, total: 12, restHint: "核实" },
    { k: "贷款逾期", done: 10, total: 33, restHint: "催收" },
    { k: "生日提醒", done: 1, total: 12, restHint: "跟进" },
    { k: "信用卡待办", done: 31, total: 54, restHint: "跟进" }
  ],
  highlight: "信用卡待办与上日大额异动推进有序，核心业务办理和风险核验工作稳步开展，保障了日常展业不断档。",
  problem: "产品到期、贷款逾期、生日提醒完成率偏低。生日提醒完成率低于 10%，存在客户关怀空窗、关系温度下降的风险。"
};

HXZ.PAYROLL = [
  { custId: "100017", avg: "50,000.00元", last: "8月10日" },
  { custId: "100018", avg: "28,600.00元", last: "8月08日" }
];

HXZ.CHURN = [
  { custId: "100017", aum: "50,000.00元", level: "长尾", prob: 80 },
  { custId: "100019", aum: "42,000.00元", level: "万元户", prob: 46 }
];

HXZ.GROUPS = ["代发客群", "到期承接池", "高净值潜力"];

HXZ.NEWS = {
  points: [
    "债市情绪平稳，短端利率小幅下行，现金管理类产品近7日年化整体持稳。",
    "权益市场分化，自由现金流与红利指数波动加大，适合用「稳健+卫星」话术解释回撤。",
    "结构性存款与大额存单仍是到期资金的主要承接工具，注意匹配客户流动性。",
    "监管提示：向客户介绍理财时须同步揭示风险，不得承诺保本保收益。"
  ],
  tip: "今日可把「产品到期」名单与短端稳健产品放在一起讲：先接住流动性，再视风测谈增强。"
};

HXZ.HISTORY_SEED = [
  { id: "s-hist-1", title: "对比安盈和苏银恒源", time: "昨天 18:22", preview: "已为您生成两只理财产品的对比结论" },
  { id: "s-hist-2", title: "查一下王芳", time: "昨天 09:14", preview: "已展示客户画像与开场白话术" },
  { id: "s-hist-3", title: "我有什么待办", time: "08-22 08:03", preview: "请选择待办类型" }
];

HXZ.SCRIPTS = {
  openingCasual: "王芳，您好，我是您的专属客户经理李明。最近注意到您一直很关注我们的理财服务，也看到您最近30天又重新浏览了理财页面，特别想跟您聊聊——您最近有没有考虑过，把手头的存款安排得更灵活一些，既能稳稳守住本金，又能适当提升一点收益？我这边有一些适合您的新方案，不占时间，也不用折腾，您看今天下午2点到4点之间，方便我花5分钟给您简单介绍一下吗？",
  openingPro: "王芳女士您好，我是您的专属客户经理李明。结合您近30天在手机银行理财频道的浏览行为，以及当前存款与理财持仓结构，建议就流动性安排做一次简短沟通：在本金相对稳健的前提下，评估是否将部分活期/到期资金匹配短期限、风险等级不超过您测评结果的产品。如您方便，建议今日 14:00–16:00 进行约5分钟电话沟通，具体方案以产品合同及风险揭示书为准。\n\n如想转换话术风格，请这样说：生成口语化版本",
  productCasual: "「安盈」稳利这一年期固收理财，可以把它理解成「长跑选手」：最短持有180天，主要投固收，风险R2，成立以来年化3.56%，100元就能起购。适合王芳这种有结算资金进出、但希望留一部分钱在行内慢慢增值的客户。封闭/最短持有的好处是少折腾、也少申赎成本。\n\n过往业绩不代表未来表现，请以产品合同为准。",
  productPro: "「安盈」稳利1年固定收益类理财产品（AXLCSH20253001）为R2中低风险、最短持有180天的固定期限产品，管理机构为安鑫理财，起购金额100元，展示指标为成立以来年化3.56%。资产配置以固定收益类为主（不低于60%）。该产品与客户稳健型风测及短期流动性偏好需在沟通中做匹配说明：若客户对流动性要求高于180天，应提示持有期约束并提供替代方案。\n\n过往业绩不代表未来表现，请以产品合同及风险揭示书为准。\n\n如想转换话术风格，请这样说：生成口语化版本",
  rightCasual: "这个贵宾机场休息室是已经发给您、还没用的权益，本季度还能用2次，提前2小时预约就行。您出差或接送家人的时候用上，等于把银行服务「带出门」，也不增加额外门槛。",
  activityCasual: "咱们最近有个新发卡理财组合包：100元就能起投，还打8.9折，可以顺便配基金。您在手机银行理财页就能参加，活动到8月30日。适合想小额定投、先体验一把的客户。"
};

HXZ.COMPARE_SUMMARY = "安盈更像「长跑选手」：最短持有180天、R2中低风险，以固收底仓走稳健复利；苏银恒源更像「短跑选手」：最短持有90天、R3中风险，可转债与黄金增强带来更高弹性。若客户在意灵活变现，苏银恒源（T+2到账）流动性更好；若更在意稳健持有体验，安盈风险更低。";
HXZ.COMPARE_LIQ = "苏银恒源最短持有90天、赎回到账T+2，安盈最短持有180天、到账T+3。两者起购与申购费无实质差异，流动性优势在苏银恒源。";
HXZ.COMPARE_INV = "安盈以固收底仓为主，波动更克制；苏银恒源在固收基础上增加可转债与黄金，收益弹性更高。";
HXZ.COMPARE_PERF = "近一年维度苏银恒源成立以来年化更高（5.71% vs 3.56%），同时风险等级为R3，需向客户同时揭示回撤可能。";
