(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const uid = () => "m" + Math.random().toString(36).slice(2, 9);

  const state = {
    mode: "app",
    busy: false,
    brandOn: true,
    recTab: "wm",
    compareTab: "basic",
    fundTab: "cum",
    wmTab: "nav",
    range: "1m",
    overlay: null,
    sheet: null,
    lastScript: null,
    currentCustomer: null,
    currentProduct: null,
    lastIntent: null,
    custQueryTab: "search",
    prodQueryTab: "search",
    prodCat: "wm",
    compareCat: "wm",
    compareA: null,
    compareB: null,
    filters: { groups: "", holds: [], fundKlass: [], wmCat: [] },
    moreFilter: { age: "", gender: "", level: "" },
    sessions: [],
    session: null,
    pickTarget: null,
    saveForm: { name: "", biz: "", goal: "", end: "" }
  };

  function newSession() {
    const s = { id: uid(), title: "新对话", time: "刚刚", preview: "欢迎使用易小助", messages: [], hasInteracted: false };
    state.sessions.unshift(s);
    state.session = s;
    state.currentCustomer = null;
    state.currentProduct = null;
    state.lastScript = null;
    state.lastIntent = null;
    state.brandOn = true;
    state.compareA = null;
    state.compareB = null;
    state.compareCat = "wm";
    state.compareTab = "basic";
    state.recTab = "wm";
    state.overlay = null;
    state.sheet = null;
    state.custQueryTab = "search";
    state.prodQueryTab = "search";
    state.prodCat = "wm";
    state.pickTarget = null;
    state.busy = false;
    state.filters = { groups: "", holds: [], fundKlass: [], wmCat: [] };
    state.saveForm = { name: "", biz: "", goal: "", end: "" };
    s.messages.push({ id: uid(), kind: "home" });
    return s;
  }

  function openingScript(c, style) {
    if (!c) return "";
    if (c.id === "100017") return style === "pro" ? HXZ.SCRIPTS.openingPro : HXZ.SCRIPTS.openingCasual;
    const casual = `${c.name}，您好，我是您的专属客户经理${HXZ.RM.name}。看到您是${c.job}，目前行内资产约 ${c.aum.toLocaleString()} 元、客户等级${c.level}。想跟您约 5 分钟，把适合您的稳健安排过一遍，您看今天上午 9–11 点方便吗？`;
    const pro = `${c.name}您好，我是您的专属客户经理${HXZ.RM.name}。结合您的职业（${c.job}）与行内客户等级（${c.level}），建议就资产配置与流动性安排做一次约 5 分钟沟通。具体方案以产品合同及风险揭示书为准。\n\n如想转换话术风格，请这样说：生成口语化版本`;
    return style === "pro" ? pro : casual;
  }
  function cust(id) {
    return HXZ.CUSTOMERS.find((c) => String(c.id) === String(id));
  }
  function product(id) {
    return [...HXZ.PRODUCTS.wm, ...HXZ.PRODUCTS.fund, ...HXZ.PRODUCTS.ins].find((p) => p.id === id || p.code === id || p.name.includes(id));
  }
  function allInvestProducts() {
    return [...HXZ.PRODUCTS.wm, ...HXZ.PRODUCTS.fund, ...HXZ.PRODUCTS.ins];
  }
  function productKeys(p) {
    const keys = [p.name, p.code, p.id];
    if (p.name.includes("安盈")) keys.push("安盈");
    if (p.name.includes("恒源")) keys.push("恒源", "苏银恒源");
    if (p.name.includes("日添利") || p.name.includes("现金管理类理财")) keys.push("日添利");
    if (p.name.includes("金吉利")) keys.push("金吉利");
    if (p.name.includes("臻享") || p.name.includes("传家")) keys.push("臻享", "传家", "臻享传家");
    if (p.name.includes("鑫如意")) keys.push("鑫如意");
    if (p.name.includes("余额宝")) keys.push("余额宝");
    if (p.monetary || (p.klass && p.klass.includes("货币"))) keys.push("货币基金", "货币");
    if (p.name.includes("祥盈")) keys.push("祥盈", "西部利得");
    if (p.name.includes("现金流") || p.name.includes("富时")) keys.push("现金流", "自由现金", "富时");
    return keys.filter(Boolean);
  }
  function productHits(t) {
    const pool = allInvestProducts();
    const scored = [];
    pool.forEach((p) => {
      productKeys(p).forEach((k) => {
        if (k && t.includes(k)) scored.push({ p, k, n: k.length });
      });
    });
    scored.sort((a, b) => b.n - a.n);
    const picked = new Map();
    const used = [];
    scored.forEach((m) => {
      if (picked.has(m.p.id)) return;
      if (used.some((k) => k.includes(m.k) && k.length > m.k.length)) return;
      picked.set(m.p.id, m.k);
      used.push(m.k);
    });
    const rows = [...picked.entries()].map(([id, k]) => ({
      p: pool.find((x) => x.id === id),
      i: t.indexOf(k)
    })).filter((x) => x.p);
    rows.sort((a, b) => a.i - b.i);
    return rows.map((x) => x.p);
  }
  function customerHits(t) {
    const exact = HXZ.CUSTOMERS.filter((c) => t.includes(c.name));
    if (exact.length) return exact;
    let rest = t.replace(/^查(一下)?/, "").replace(/^客户/, "");
    rest = rest.replace(/(的)?(画像|开场白)$/, "");
    if (/^[\u4e00-\u9fa5]{1,4}$/.test(rest) && !/产品|理财|基金|保险|待办|商机|资讯|客户/.test(rest)) {
      return HXZ.CUSTOMERS.filter((c) => c.name.includes(rest));
    }
    return [];
  }

  function toast(t) {
    const el = $("#toast");
    el.hidden = false;
    el.textContent = t;
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.hidden = true; }, 2000);
  }

  function genderCap(g) {
    if (g === "女") return `<span class="cap f">♀ 女性</span>`;
    if (g === "男") return `<span class="cap m">♂ 男性</span>`;
    return "";
  }

  function personLine(c) {
    return `<div class="name-line"><strong>${esc(c.name)}</strong><span class="cap">${c.age}岁</span>${genderCap(c.gender)}${c.job ? `<span class="cap">${esc(c.job)}</span>` : ""}</div>
      <div class="idline">ID ${esc(c.id)}${c.phone ? `　${esc(c.phone)}` : ""}</div>`;
  }

  function riskClass(r) {
    const n = String(r || "").toLowerCase();
    if (n.includes("r5") || n === "r5") return "r5";
    if (n.includes("r4")) return "r4";
    if (n.includes("r3")) return "r3";
    if (n.includes("r1")) return "r1";
    return "r2";
  }

  function riskBar(level) {
    const n = parseInt(String(level).replace(/\D/g, ""), 10) || 2;
    const cls = "r" + n;
    return `<div class="riskbar ${cls}">${[1,2,3,4,5].map((i) => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</div>`;
  }

  function svgLine(color = "#3768FA") {
    return `<svg class="chart" viewBox="0 0 320 120" preserveAspectRatio="none"><defs><linearGradient id="g${color.slice(1)}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".25"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
      <path d="M0,88 C40,86 60,70 90,72 C130,76 150,40 190,38 C230,36 260,28 320,22 L320,120 L0,120 Z" fill="url(#g${color.slice(1)})"/>
      <path d="M0,88 C40,86 60,70 90,72 C130,76 150,40 190,38 C230,36 260,28 320,22" fill="none" stroke="${color}" stroke-width="2"/>
      <circle cx="320" cy="22" r="3.5" fill="${color}"/></svg>`;
  }

  function svgDual() {
    return `<svg class="chart" viewBox="0 0 320 120" preserveAspectRatio="none">
      <path d="M0,90 C50,88 80,70 120,68 C180,64 220,50 320,40" fill="none" stroke="#E6002D" stroke-width="2"/>
      <path d="M0,80 C40,78 90,74 140,60 C200,44 250,48 320,30" fill="none" stroke="#3768FA" stroke-width="2"/>
    </svg>`;
  }

  function allocBar(c) {
    const palette = ["#E6002D", "#2F6FED", "#0CA678", "#F59F00", "#98A2B3"];
    const slices = c.holding.slices;
    const sum = slices.reduce((a, b) => a + b.v, 0);
    const segs = slices.map((s, i) => `<i style="width:${(s.v / sum * 100).toFixed(1)}%;background:${palette[i % palette.length]}"></i>`).join("");
    const legend = slices.map((s, i) => `<span><i style="background:${palette[i % palette.length]}"></i>${s.k} ${(s.v / sum * 100).toFixed(0)}%</span>`).join("");
    return `<div class="alloc"><div class="alloc-bar">${segs}</div><div class="alloc-legend">${legend}</div></div>`;
  }

  function ring(pct) {
    const r = 24, c = 2 * Math.PI * r;
    const off = (c * (1 - pct / 100)).toFixed(1);
    const color = pct >= 80 ? "#0CA678" : pct >= 50 ? "#F59F00" : "#E6002D";
    return `<svg class="ring" viewBox="0 0 56 56"><circle cx="28" cy="28" r="${r}" fill="none" stroke="#EBEEF4" stroke-width="5"/><circle cx="28" cy="28" r="${r}" fill="none" stroke="${color}" stroke-width="5" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${off}" transform="rotate(-90 28 28)"/></svg>`;
  }

  function parseNum(s) { return parseFloat(String(s).replace(/[^\d.]/g, "")) || 0; }

  function cmpBarRow(l, m, r) {
    const a = parseNum(l), b = parseNum(r);
    const max = Math.max(a, b, 0.01);
    const aWin = a >= b;
    return `<div class="cmp-row">
      <div class="cr-top"><div class="cv ${aWin ? "win" : ""}">${esc(l)}</div><div class="mid">${esc(m)}</div><div class="cv ${aWin ? "" : "win"}">${esc(r)}</div></div>
      <div class="cbars"><span class="cb-l ${aWin ? "win" : ""}"><i style="width:${(a / max * 100).toFixed(0)}%"></i></span><span class="cb-r ${aWin ? "" : "win"}"><i style="width:${(b / max * 100).toFixed(0)}%"></i></span></div>
    </div>`;
  }

  function scrollEnd() {
    const el = $("#stream");
    const last = el && el.lastElementChild;
    const go = () => {
      if (!el || !last) return;
      const top = last.getBoundingClientRect().top - el.getBoundingClientRect().top + el.scrollTop;
      el.scrollTop = Math.max(0, top - 6);
    };
    requestAnimationFrame(() => requestAnimationFrame(go));
  }

  function push(msg) {
    state.session.messages.push(msg);
    if (msg.kind === "user") {
      state.session.hasInteracted = true;
      state.brandOn = false;
      state.session.title = msg.text.slice(0, 20);
      state.session.time = "刚刚";
      state.session.preview = msg.text;
    }
    render();
    scrollEnd();
  }

  function addUser(text) { push({ id: uid(), kind: "user", text }); }
  function addMeta(text) { push({ id: uid(), kind: "meta", text }); }
  function addAI(text) { push({ id: uid(), kind: "ai", text }); }
  function addCard(type, payload) { push({ id: uid(), kind: "card", type, payload: payload || {} }); }

  async function withQuery(fn, ms = 700) {
    if (state.busy) return;
    state.busy = true;
    $("#typing").hidden = false;
    $("#sendBtn").disabled = true;
    await sleep(ms);
    $("#typing").hidden = true;
    state.busy = false;
    if (ms >= 1000) addMeta(`查询完毕 (用时 ${(ms / 1000).toFixed(1).replace(/\.0$/, "")}秒)`);
    try {
      await fn();
    } catch (err) {
      console.error(err);
      addAI("查询结果生成失败，请稍后重试。");
    }
    $("#sendBtn").disabled = !$("#input").value.trim();
  }

  /* ——— renderers ——— */
  function todoCount(key) {
    const list = HXZ.TODOS[key] || [];
    if (key === "contact") return list.length;
    return list.filter((t) => !t.handled).length;
  }
  function totalOpen() {
    return ["expire", "move", "loan", "birthday", "contact", "card"].reduce((n, k) => n + todoCount(k), 0);
  }
  function featuredTask() {
    const labels = { expire: "产品到期", move: "资产大幅变动", loan: "贷款逾期", birthday: "生日提醒", contact: "联络超期", card: "信用卡待办" };
    const order = ["loan", "expire", "contact", "move", "card", "birthday"];
    for (let i = 0; i < order.length; i++) {
      const type = order[i];
      const items = (HXZ.TODOS[type] || []).filter((t) => type === "contact" || !t.handled);
      const t = items[0];
      const c = t && cust(t.custId);
      if (c) return { type, t, c, label: labels[type] };
    }
    return null;
  }
  function featuredCopy(ft) {
    if (!ft) return { title: "今日待办已清", body: "可以去查客户或筛产品，为下午约访做准备。" };
    const { type, t, c, label } = ft;
    if (type === "loan") return { title: `${c.name} · ${label}`, body: `${t.name} 逾期 ${t.overdueAmt}，已 ${t.days} 天。建议先核实还款日，再决定是否上门。` };
    if (type === "expire") {
      const p = t.products[0];
      return { title: `${c.name} · ${label}`, body: `${p.name} ${p.amt}，${p.date} 到期。先确认是否续存，再配期限匹配的承接产品。` };
    }
    if (type === "contact") return { title: `${c.name} · ${label}`, body: `已 ${t.days} 天未联络，资产 ${t.aum}。补一次电话，避免关系降温。` };
    if (type === "move") return { title: `${c.name} · ${label}`, body: `上日异动 ${t.delta >= 0 ? "+" : ""}${t.delta.toLocaleString()} 元，当前余额 ${t.bal}。先核实资金来源/去向。` };
    if (type === "birthday") return { title: `${c.name} · ${label}`, body: `距生日 ${t.left} 天。可结合权益或生日礼做一次轻触达。` };
    return { title: `${c.name} · ${label}`, body: `${t.biz || "待办"} · ${t.acct || ""}`.trim() };
  }
  function talkTrack(c) {
    if (c.id === "100017") return { title: "结算款留存弱，先接住 8/28 到期的 5 万", body: "入金后当月几乎全部转出。风测稳健有效，电话窗口建议上午 9–11 点。面谈先讲流动性，再拿出安盈这类 R2、180 天产品。" };
    if (c.id === "100018") return { title: "风测已过期，理财先不要开口", body: "财富层级 20–50 万，但测评过期。先引导补测，存款与联络仍可做；理财/基金推荐需等有效风测。" };
    if (c.id === "100019") return { title: "未完成风测，用存款承接到期资金", body: "退休客群、偏好短期限。今日有产品到期待跟进。未风测前只谈存款与服务，不推理财基金。" };
    return { title: `先读懂 ${c.name} 的资产与联络习惯`, body: c.behavior.finance };
  }

  function renderHome() {
    const open = totalOpen();
    const ft = featuredTask();
    const copy = featuredCopy(ft);
    const tasks = [
      ["expire", "产品到期"], ["move", "资产变动"], ["loan", "贷款逾期"],
      ["birthday", "生日提醒"], ["contact", "联络超期"], ["card", "信用卡"]
    ];
    const loanOpen = todoCount("loan"), expOpen = todoCount("expire");
    return `<article class="card home">
      <div class="hm-top">
        <div><div class="hm-hi">${esc(HXZ.RM.name)}，早上好</div><div class="hm-date">${HXZ.TODAY_LABEL} · 晨间概览</div></div>
        <span class="hm-badge">AI 展业助手</span>
      </div>
      <div class="hm-stats">
        <div class="stat"><div class="n">${open}</div><div class="l">待处理</div></div>
        <div class="stat"><div class="n ${loanOpen ? "red" : ""}">${loanOpen}</div><div class="l">贷款逾期</div></div>
        <div class="stat"><div class="n">${expOpen}</div><div class="l">产品到期</div></div>
      </div>
      <div class="prio">
        <div class="prio-tag">今日优先 · ${ft ? ft.label : "待办"}</div>
        <div class="prio-name">${esc(copy.title)}</div>
        <p class="prio-hint">${esc(copy.body)}</p>
        <div class="prio-acts">
          <button class="btn-red" data-act="todo" data-type="${ft ? ft.type : "expire"}">${ft ? "打开名单" : "查看待办"}</button>
          ${ft ? `<button class="btn-line" data-act="open-portrait" data-id="${ft.c.id}">看客户</button>` : ""}
        </div>
      </div>
      <div class="sec-t">今日待办</div>
      <div class="todo-grid">
        ${tasks.map(([k, n]) => {
          const cnt = todoCount(k);
          const hot = ft && ft.type === k && cnt > 0;
          return `<button class="todo-cell ${cnt ? "pending" : ""}${hot ? " hot" : ""}${cnt ? "" : " idle"}" data-act="todo" data-type="${k}">
            ${hot ? `<em class="tc-prio">优先</em>` : ""}
            <span class="tc-n ${cnt ? "warn" : "zero"}">${cnt}</span>
            <span class="tc-l">${n}</span>
          </button>`;
        }).join("")}
      </div>
      <button class="ring-row" data-act="yday-rate">
        ${ring(parseFloat(HXZ.YDAY.rate) || 0)}
        <span class="rr-t"><b>昨日完成率 ${HXZ.YDAY.rate}</b><span>点击查看昨日完成情况</span></span>
        <span class="chev">›</span>
      </button>
      <button class="link-row" data-act="yday-sum">昨日工作总结<span class="chev">›</span></button>
      <div class="sec-t">洞察工具</div>
      <div class="tool-duo">
        <button class="tool-c" data-act="open-cust"><svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-3.3 0-7 1.7-7 4v2h14v-2c0-2.3-3.7-4-7-4z"/></svg>查客户<span>画像 · 怎么谈</span></button>
        <button class="tool-c" data-act="open-prod"><svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M4 5h16v3H4zm0 5.5h16v3H4zm0 5.5h10v3H4z"/></svg>查产品<span>筛选 · 对比</span></button>
      </div>
      <div class="sec-t">商机</div>
      <div class="opp-duo">
        <button class="opp-c" data-act="payroll"><b>${HXZ.PAYROLL.length} 人</b>代发即将到账<span>未来 7 天</span></button>
        <button class="opp-c warn" data-act="churn"><b>${HXZ.CHURN.length} 人</b>流失预警<span>高风险客户</span></button>
      </div>
      <button class="link-row" data-act="news">今日市场简报<span class="chev">›</span></button>
    </article>`;
  }

  function renderCustQuery() {
    const tab = state.custQueryTab;
    const f = state.filters;
    const search = `<div class="field"><label>客户号</label><input data-f="cid" placeholder="请输入" /></div>
      <div class="field"><label>证件号</label><input data-f="idno" placeholder="请输入" /></div>
      <div class="field"><label>手机号</label><input data-f="mobile" inputmode="numeric" placeholder="请输入" /></div>
      <div class="field"><label>姓名</label><input data-f="name" placeholder="请输入" /></div>`;
    const filter = `<div class="subtxt" style="margin-bottom:6px">客群</div>
      <div class="tags">${HXZ.GROUPS.map((g) => `<button class="tag ${f.groups === g ? "on" : ""}" data-act="chip-group" data-v="${esc(g)}">${esc(g)}</button>`).join("")}</div>
      <div class="subtxt" style="margin:10px 0 6px">持有产品</div>
      <div class="tags">${["理财","基金","保险","消费贷","经营贷","房贷"].map((p) => `<button class="tag ${f.holds.includes(p) ? "on" : ""}" data-act="chip-hold" data-v="${p}">${p}</button>`).join("")}</div>
      <button class="more-link" data-act="more-cust">更多筛选条件 ›</button>`;
    return `<article class="card" data-card="custq">
      <div class="card-hd"><b>查找管户客户</b></div>
      <p class="subtxt">用客户号、证件、手机或姓名精确查找；也可按客群筛选。</p>
      <div class="seg"><button class="${tab === "search" ? "on" : ""}" data-act="cust-tab" data-tab="search">搜索</button><button class="${tab === "filter" ? "on" : ""}" data-act="cust-tab" data-tab="filter">筛选</button></div>
      ${tab === "search" ? search : filter}
      <button class="btn-primary" data-act="do-cust-query">查询</button>
    </article>`;
  }

  function renderCustList(ids, mode) {
    const list = ids.map((id) => cust(id)).filter(Boolean);
    return `<article class="card">
      <div class="card-hd"><b>${mode === "clarify" ? "查询到多个客户，请确认是哪一个" : "已查询到符合条件的客户"}</b></div>
      ${mode !== "clarify" ? `<div class="subtxt">共查询到 ${list.length} 位客户</div>` : ""}
      ${list.map((c) => `<button class="cust-row" data-act="open-portrait" data-id="${c.id}" style="width:100%;text-align:left">
        <div class="cust-main">${personLine(c)}</div><span class="chev">›</span></button>`).join("")}
      ${mode !== "clarify" ? `<button class="btn-primary" data-act="save-group">保存客群</button>` : ""}
    </article>`;
  }

  function renderPortrait(c, payload) {
    if (!c) return `<article class="card"><p>未查询到该客户，请确认是否为您的管户客户。</p></article>`;
    const recTab = (payload && payload.recTab) || state.recTab;
    const sysTags = [c.industry, c.job, c.city, c.edu].filter(Boolean);
    const honorific = c.gender === "女" ? "女士" : "先生";
    const ageBand = c.age < 45 ? "中年" : "中老年";
    const sexWord = c.gender === "女" ? "女性" : "男性";
    const track = talkTrack(c);
    const riskHint = c.riskStatus === "valid" ? `${esc(c.risk)} · 风测有效` : (c.riskStatus === "expired" ? "风测已过期" : "未完成风测");
    return `<article class="card person-card" data-portrait="${c.id}">
      <div class="person-hd">
        <div class="avatar">${esc(c.name[0])}</div>
        <div class="cust-main">
          ${personLine(c)}
          <div class="p-tags"><span class="ptag ${c.riskStatus === "valid" ? "r2" : "warn"}">${riskHint}</span><span class="ptag gray">${esc(c.level)}</span>${sysTags.map((t) => `<span class="ptag gray">${esc(t)}</span>`).join("")}</div>
          ${c.tags.length ? `<div class="p-tags">${c.tags.map((t) => `<span class="ptag cat">${esc(t)}</span>`).join("")}</div>` : ""}
        </div>
      </div>
      <div class="insight">
        <div class="ins-lab">今日怎么谈</div>
        <b>${esc(track.title)}</b>
        <p>${esc(track.body)}</p>
      </div>
      <div class="anchors">
        <button class="on" data-act="jump" data-to="profile">档案</button><button data-act="jump" data-to="wealth">财富</button><button data-act="jump" data-to="credit">信贷</button><button data-act="jump" data-to="behavior">行为</button><button data-act="jump" data-to="script">话术</button><button data-act="jump" data-to="rec">推荐</button>
      </div>
      <section class="mod" data-sec="profile">
        <h3>客户档案</h3>
        <p>${esc(c.name[0])}${honorific}，${ageBand}${sexWord} · ${esc(c.industry || "")} · ${esc(c.job)} · ${esc(c.city)} · ${esc(c.edu)}</p>
        <p>家庭：${esc(c.family)}</p>
        ${c.biz ? `<p>经营：${esc(c.biz.name)}，${esc(c.biz.years)}，持股${esc(c.biz.share)}，注册资金${esc(c.biz.capital)}。${esc(c.biz.continuity)}</p>` : ""}
      </section>
      <section class="mod" data-sec="wealth">
        <h3>财富</h3>
        <div class="aum-hero">
          <div class="aum-n">${c.aum.toLocaleString()}<span>元</span></div>
          <div class="aum-l">${esc(c.level)} · 财富分 <em>${c.wealthScore}</em> <button class="i-btn" data-act="wealth-tip">规则</button></div>
        </div>
        ${allocBar(c)}
        <div class="mgrid">
          <div class="mcell"><div class="n">${esc(c.cash.inAmt)}</div><div class="l">近一年入金（元）</div></div>
          <div class="mcell"><div class="n">${esc(c.cash.outAmt)}</div><div class="l">近一年出金（元）</div></div>
          <div class="mcell"><div class="n red">+${c.holding.pnl.toLocaleString()}</div><div class="l">持仓累计收益（元）</div></div>
          <div class="mcell"><div class="n">${esc(c.holding.annual)}</div><div class="l">持仓年化 · 高点 ${esc(c.holding.peak)}</div></div>
        </div>
        <p class="note">入金：${esc(c.cash.inDesc)}</p>
        <p class="note">出金：${esc(c.cash.outDesc)}</p>
      </section>
      ${c.credit ? `<section class="mod" data-sec="credit">
        <h3>信贷</h3>
        <p style="margin-bottom:6px">在途 <em>${c.credit.count}</em> 笔，余额 <em>${esc(c.credit.bal)}</em> 元</p>
        ${c.credit.loans.map((l) => {
          const limit = parseNum(l.limit), used = parseNum(l.used);
          const pct = limit ? Math.min(100, used / limit * 100).toFixed(0) : 0;
          return `<div class="loan">
            <div class="loan-hd"><b>${esc(l.name)}</b>${l.overdue ? `<span><em>逾期 ${l.overdue} 次</em></span>` : `<span>无逾期</span>`}</div>
            <div class="util"><i style="width:${pct}%"></i></div>
            <div class="loan-meta">已用 ${esc(l.used)} / 授信 ${esc(l.limit)} · 剩余 ${esc(l.left)}</div>
          </div>`;
        }).join("")}
        ${c.credit.reject ? `<p class="note">曾申请${esc(c.credit.reject.name)}，${esc(c.credit.reject.reason)}（${esc(c.credit.reject.date)}）</p>` : ""}
        <p class="note">公积金 ${esc(c.credit.gjj)} · 社保 ${esc(c.credit.sb)}</p>
      </section>` : `<section class="mod" data-sec="credit"><h3>信贷</h3><p>暂无在途贷款。</p></section>`}
      <section class="mod" data-sec="behavior">
        <h3>行为</h3>
        <div class="b-row"><b>金融偏好</b><span>${esc(c.behavior.finance)}</span></div>
        <div class="b-row"><b>流动性</b><span>${esc(c.behavior.liquidity)}</span></div>
        <div class="b-row"><b>风险</b><span>${esc(c.behavior.risk)}</span></div>
        <div class="b-row"><b>触达</b><span>${esc(c.behavior.market)}</span></div>
        <div class="b-row"><b>代发</b><span>${esc(c.behavior.payroll)}</span></div>
        ${c.behavior.other ? `<div class="b-row"><b>其他</b><span>${esc(c.behavior.other)}</span></div>` : ""}
      </section>
      <section class="mod" data-sec="script">
        <h3>可直接开口</h3>
        <div class="script">${esc(openingScript(c, "casual"))}</div>
        <div class="script-acts">
          <button data-act="copy" data-text="${esc(openingScript(c, "casual"))}">复制话术</button>
          <button data-act="style-pro" data-from="opening">换成书面表达</button>
        </div>
      </section>
      <section class="mod" data-sec="rec">${renderRec(c, recTab)}</section>
    </article>`;
  }

  function recProducts(c, recTab) {
    if (recTab === "wm") return HXZ.PRODUCTS.wm.filter((p) => ["R1","R2"].includes(p.risk) || c.riskStatus === "valid").slice(0, 3);
    if (recTab === "fund") return HXZ.PRODUCTS.fund.filter((p) => p.risk !== "R4" && p.risk !== "R5").slice(0, 3);
    if (recTab === "dep") return HXZ.PRODUCTS.deposit.slice(0, 3);
    if (recTab === "right") return HXZ.RIGHTS;
    return HXZ.ACTIVITIES;
  }

  function renderRec(c, recTab) {
    recTab = recTab || "wm";
    const blocked = (recTab === "wm" || recTab === "fund") && c.riskStatus !== "valid";
    const tabs = [["wm","理财推荐"],["fund","基金推荐"],["dep","存款推荐"],["right","权益推荐"],["act","活动推荐"]];
    let body = "";
    if (blocked) {
      const invite = c.riskStatus === "expired"
        ? `${c.name}，您的风险测评已过期。按监管要求，理财和基金需要有效测评才能办理。我帮您约 5 分钟补测，测完再按结果给您配产品。`
        : `${c.name}，您好。购买理财或基金前需要做一次风险测评，手机银行大约 5 分钟就能完成。做完我按您的结果匹配产品。`;
      body = `<div class="empty"><span class="star">☆</span>${c.riskStatus === "expired" ? "风险测评已过期" : "客户未完成风险测评"}</div>
        <div class="insight"><div class="ins-lab">下一步</div><b>先补风测，再开口理财</b><p>存款与服务可以继续谈。理财 / 基金需等有效测评。</p></div>
        <div class="script-acts"><button data-act="copy" data-text="${esc(invite)}">复制补测邀约</button></div>`;
    } else if (recTab === "right" || recTab === "act") {
      body = recProducts(c, recTab).map((x) => `<div class="t-card" data-act="${recTab === "right" ? "right-script" : "act-script"}" data-id="${x.id}">
        <strong>${esc(x.name)}</strong><p class="subtxt" style="margin-top:6px">${esc(x.desc)}</p>
        <p class="subtxt" style="margin-top:6px">有效期：${esc(x.period)}</p></div>`).join("") + `<button class="btn-ghost">查看全部</button>`;
    } else if (recTab === "dep") {
      body = recProducts(c, recTab).map((p) => `<button class="p-card" data-act="dep-script" data-id="${p.id}" style="width:100%;text-align:left">
        <div class="p-name">${esc(p.name)}</div>
        <div class="p-tags"><span class="ptag gray">${esc(p.tag)}</span></div>
        <div class="metrics"><div><div class="big">${esc(p.rate)}</div><div class="lab">年利率</div></div>
        <div><div class="big ink">${esc(p.term)}</div><div class="lab">${esc(p.minAmt)}起存</div></div></div>
      </button>`).join("");
    } else {
      const list = recProducts(c, recTab);
      const stars = HXZ.PRODUCTS.wm.filter((p) => p.star);
      if (!list.length) {
        body = `<div class="empty"><span class="star">☆</span>暂无产品推荐</div>`;
        if (recTab === "wm" && c.riskStatus === "valid" && stars.length) body += stars.slice(0, 3).map(miniProduct).join("");
      } else {
        body = list.map((p) => miniProduct(p)).join("");
        if (recTab === "wm" && c.riskStatus === "valid") body += `<button class="btn-ghost" data-act="stars">查看明星产品</button>`;
      }
    }
    return `<div>
      <h3>可搭配的产品</h3>
      <div class="rec-tabs">${tabs.map(([k,n]) => `<button class="${recTab===k?"on":""}" data-act="rec-tab" data-tab="${k}">${n}</button>`).join("")}</div>
      ${body}
    </div>`;
  }

  function miniProduct(p) {
    if (p.type === "fund") {
      const left = p.monetary ? p.yield : (p.daily || p.yield);
      const leftLab = p.monetary ? `近7日年化（${p.date}）` : `日涨幅（${p.date}）`;
      const right = p.monetary ? `${p.wanfen}元` : (p.klass2 || p.klass);
      const rightLab = p.monetary ? `万份收益（${p.date}）` : `${p.klass}`;
      const neg = String(left).startsWith("-");
      return `<button class="p-card" data-act="open-prod-id" data-id="${p.id}" style="width:100%;text-align:left">
        <div class="p-name">${esc(p.name)}</div>
        <div class="p-tags"><span class="ptag cat">基金 | ${esc(p.klass)}</span><span class="ptag ${riskClass(p.risk)}">${esc(p.riskLabel)}</span>${p.agency ? `<span class="ptag gray">代销</span>` : ""}</div>
        <div class="metrics"><div><div class="big ${neg?"down":""}">${esc(left)}</div><div class="lab">${esc(leftLab)}</div></div>
        <div><div class="big ink">${esc(right)}</div><div class="lab">${esc(rightLab)}</div></div></div>
      </button>`;
    }
    if (p.type === "ins") {
      return `<button class="p-card" data-act="open-prod-id" data-id="${p.id}" style="width:100%;text-align:left">
        <div class="p-name">${esc(p.name)}</div>
        <div class="p-tags"><span class="ptag gray">${esc(p.cat)}</span><span class="ptag ${riskClass(p.risk)}">${esc(p.riskLabel)}</span></div>
        <div class="metrics" style="grid-template-columns:1fr 1fr 1fr">
          <div><div class="big">${esc(p.coverYears)}</div><div class="lab">保障期限</div></div>
          <div><div class="big ink">${esc(p.premium)}</div><div class="lab">保费</div></div>
          <div><div class="big ink">${esc(p.payYears)}</div><div class="lab">交费年期</div></div>
        </div>
      </button>`;
    }
    return `<button class="p-card" data-act="open-prod-id" data-id="${p.id}" style="width:100%;text-align:left">
      <div class="p-name">${esc(p.name)}</div>
      <div class="p-tags"><span class="ptag cat">理财</span><span class="ptag ${riskClass(p.risk)}">${esc(p.riskLabel)}</span></div>
      <div class="metrics"><div><div class="big">${esc(p.yield)}</div><div class="lab">${esc(p.yieldType)}</div></div>
      <div><div class="big ink">${esc(p.rules)}</div><div class="lab">${esc(p.minAmt)}起购</div></div></div>
    </button>`;
  }

  function renderProdQuery() {
    const tab = state.prodQueryTab;
    const cat = state.prodCat;
    const cats = [["wm","理财"],["fund","基金"],["ins","保险"]];
    let filters = "";
    if (cat === "wm") {
      filters = rowChips("理财类别", ["活钱理财","按日开放","固定期限","定期开放","悦享周期","外币理财"], "wmCat")
        + rowChips("投资期限", ["无固定期限","灵活期限","定期开放","固定期限"], "wmTerm")
        + rowChips("收益率", ["<0%","0–1%","1–2%","2–3%","≥3%"], "wmY")
        + rowChips("风险等级", ["R1低风险","R2中低风险","R3中风险","R4中高风险","R5高风险"], "wmR");
    } else if (cat === "fund") {
      filters = rowChips("基金类别", ["货币型","债券型","混合型","股票型","商品型","REITs","FOF","QDII","其他"], "fundKlass")
        + rowChips("风险等级", ["R1低风险","R2中低风险","R3中风险","R4中高风险","R5高风险"], "fundR");
    } else {
      filters = rowChips("险种类型", ["寿险","产险","其他"], "insCat")
        + rowChips("缴费类型", ["年缴","趸缴"], "insPay");
    }
    return `<article class="card" data-card="prodq">
      <div class="card-hd"><b>查找可销产品</b></div>
      <p class="subtxt">支持理财、基金、保险。先搜名称或代码，或按条件筛选。</p>
      <div class="seg"><button class="${tab==="search"?"on":""}" data-act="prod-tab" data-tab="search">搜索</button><button class="${tab==="filter"?"on":""}" data-act="prod-tab" data-tab="filter">筛选</button></div>
      ${tab === "search" ? `<div class="field"><label>查询条件</label><input data-f="pkey" placeholder="请输入产品名称或代码" /></div>` : `
        <div class="rec-tabs">${cats.map(([k,n]) => `<button class="${cat===k?"on":""}" data-act="prod-cat" data-tab="${k}">${n}</button>`).join("")}</div>
        ${filters}
        <button class="more-link" data-act="more-prod">更多筛选条件 ›</button>`}
      <button class="btn-primary" data-act="do-prod-query">查询</button>
    </article>`;
  }

  function rowChips(label, items, key) {
    const sel = state.filters[key] || [];
    return `<div class="subtxt" style="margin:8px 0 6px">${label}</div>
      <div class="tags">${items.map((x) => `<button class="tag ${sel.includes(x)?"on":""}" data-act="chip-multi" data-key="${key}" data-v="${x}">${x}</button>`).join("")}</div>`;
  }

  function renderProdList(list, showAll, mode) {
    if (!list.length) return `<article class="card"><p>抱歉，未查询到符合条件的产品</p></article>`;
    const vis = showAll ? list : list.slice(0, 3);
    const hd = mode === "clarify" ? "查询到多个产品，请确认是哪一个" : `已为您查询到 ${list.length} 个产品。`;
    return `<article class="card">
      <div class="card-hd">${mode === "clarify" ? `<b>${hd}</b>` : hd}</div>
      ${vis.map(miniProduct).join("")}
      ${!showAll && list.length > 3 ? `<button class="btn-ghost" data-act="expand-prod">查看全部</button>` : ""}
    </article>`;
  }

  function renderWmDetail(p) {
    return `<article class="card">
      <div class="p-name" style="font-size:16px">${esc(p.name)}</div>
      <div class="idline">产品代码：${esc(p.code)}</div>
      <div class="p-tags"><span class="ptag cat">理财</span><span class="ptag ${riskClass(p.risk)}">${esc(p.riskLabel)}</span>${p.star ? `<span class="ptag warn">明星产品</span>` : ""}</div>
      <div class="yield-hero">
        <div><div class="y-n">${esc(p.yield)}</div><div class="y-l">${esc(p.yieldType)} <button class="i-btn" data-act="yield-tip">说明</button></div></div>
        <div class="y-side"><div>${esc(p.rules)}</div><div class="y-l">${esc(p.minAmt)}起购</div></div>
      </div>
      <div style="margin-top:12px">${riskBar(p.risk)}<div style="font-size:11px;color:var(--muted)">${esc(p.riskLabel)}</div></div>
      <h3>一、基础信息</h3>
      ${kv("产品名称", p.name)+kv("产品代码", p.code)+kv("成立日期", p.found)+kv("产品币种", p.currency)+kv("风险等级", p.riskLabel)+kv("管理机构", p.org)}
      <h3 style="margin-top:12px">二、交易规则</h3>
      <div class="block-title">买入规则</div>
      ${kv("确认份额时间", p.confirm)+kv("起购金额", p.minAmt)}
      <div class="block-title">赎回规则</div>
      ${kv("到账时间", p.redeemArrive)}
      <h3 style="margin-top:12px">三、投资方向</h3>
      ${(p.invest||[]).map((x)=>`<p class="subtxt" style="line-height:1.7">• ${esc(x)}</p>`).join("")}
      <h3 style="margin-top:12px">四、历史业绩</h3>
      <div class="subtxt">更新时间 2026-08-22</div>
      <table class="data"><tr><th>时间区间</th><th>区间涨跌幅</th><th>年化收益率</th></tr>
      ${(p.perf||[]).map((r)=>`<tr><td>${r.p}</td><td class="up">${r.chg}</td><td class="up">${r.ann}</td></tr>`).join("")}</table>
      <div class="tabs"><button class="${state.wmTab==="nav"?"on":""}" data-act="wm-tab" data-tab="nav">单位净值</button></div>
      ${svgLine()}
      <div class="range">${[["1m","近1月"],["3m","近3月"],["6m","近6月"],["1y","近1年"],["max","成立以来"]].map(([k,n])=>`<button class="${state.range===k?"on":""}" data-act="range" data-tab="${k}">${n}</button>`).join("")}</div>
      <button class="btn-ghost" data-act="prod-script" data-id="${p.id}">生成产品介绍话术</button>
    </article>`;
  }

  function kv(k, v) { return `<div class="kv"><span class="subtxt">${esc(k)}</span><span>${esc(v)}</span></div>`; }

  function renderFundDetail(p) {
    const left = p.monetary ? p.yield : p.daily;
    const leftLab = p.monetary ? `七日年化（${p.date}）` : `日涨幅（${p.date}）`;
    const right = p.monetary ? `${p.wanfen}元` : p.nav;
    const rightLab = p.monetary ? `万份收益（${p.date}）` : `单位净值（${p.date}）`;
    const neg = String(left).startsWith("-");
    return `<article class="card">
      <div class="p-name" style="font-size:16px">${esc(p.name)}</div>
      <div class="idline">产品代码：${esc(p.code)}</div>
      <div class="p-tags"><span class="ptag cat">基金 | ${esc(p.klass)}</span><span class="ptag ${riskClass(p.risk)}">${esc(p.riskLabel)}</span>${p.agency ? `<span class="ptag gray">代销</span>` : ""}</div>
      <div class="yield-hero">
        <div><div class="y-n ${neg ? "down" : ""}">${esc(left)}</div><div class="y-l">${esc(leftLab)}</div></div>
        <div class="y-side"><div>${esc(right)}</div><div class="y-l">${esc(rightLab)}</div></div>
      </div>
      <div style="margin-top:12px">${riskBar(p.risk)}<div style="font-size:11px;color:var(--muted)">${esc(p.riskLabel)} · ${esc(p.minAmt)}起购</div></div>
      <h3>一、基础信息</h3>
      ${kv("产品简称", p.name)+kv("产品代码", p.code)+kv("基金类型", p.klass)+kv("风险等级", p.riskLabel)+kv("成立日期", p.found)+kv("基金公司", p.company)+kv("托管人", p.trustee)}
      <h3 style="margin-top:12px">二、历史业绩</h3>
      ${p.monetary ? "" : `<div class="tabs">
        <button class="${state.fundTab==="cum"?"on":""}" data-act="fund-tab" data-tab="cum">累计收益</button>
        <button class="${state.fundTab==="nav"?"on":""}" data-act="fund-tab" data-tab="nav">单位净值</button>
        <button class="${state.fundTab==="acc"?"on":""}" data-act="fund-tab" data-tab="acc">累计净值</button>
      </div>`}
      ${svgLine("#2f6fed")}
      ${p.monetary ? "" : `<table class="data"><tr><th>时间区间</th><th>区间收益率</th><th>同类平均</th><th>同类排名</th></tr>
        <tr><td>近1月</td><td class="up">0.49%</td><td>0.49%</td><td>12/123</td></tr>
        <tr><td>近3月</td><td class="up">0.81%</td><td>0.81%</td><td>15/42</td></tr>
        <tr><td>近6月</td><td class="up">1.94%</td><td>1.94%</td><td>55/632</td></tr>
        <tr><td>近1年</td><td class="up">0.49%</td><td>0.49%</td><td>11/67</td></tr>
        <tr><td>成立以来</td><td class="up">2.64%</td><td>2.64%</td><td>-/-</td></tr></table>`}
      <h3 style="margin-top:12px">五、交易规则</h3>
      <div class="block-title">买入规则</div>
      ${kv("确认份额时间","交易日17:00前买入，T+2个交易日确认")+kv("买入费率","0<=买入金额，0.00%")+kv("起购金额",p.minAmt)+kv("管理费","0.30%(每年)")+kv("托管费","0.10%(每年)")+kv("销售服务费","0.20%(每年)")}
      <div class="block-title">卖出规则</div>
      ${kv("卖出确认时间","T日15:00前卖出，按T日基金净值确认份额")+kv("卖出费率","0<=持有天数，0.00%")}
      <button class="btn-ghost" data-act="prod-script" data-id="${p.id}">生成产品介绍话术</button>
    </article>`;
  }

  function renderInsDetail(p) {
    return `<article class="card">
      <div class="subtxt">${esc(p.company)}</div>
      <div class="p-name" style="font-size:16px">${esc(p.name)}</div>
      <div class="idline">${esc(p.subtitle)}</div>
      ${kv("产品属性", p.attr)+kv("缴费年期类型", p.payType)+kv("缴费期间", p.payYears)+kv("保障年期类型", p.coverType)+kv("保险期间", p.coverYears)+kv("风险等级", p.riskLabel)}
      <button class="btn-ghost" data-act="prod-script" data-id="${p.id}">生成产品介绍话术</button>
    </article>`;
  }

  function renderCompareEntry() {
    const cats = [["wm","理财"],["fund","基金"],["ins","保险"]];
    const a = state.compareA, b = state.compareB;
    return `<article class="card">
      <div class="card-hd">请输入对比的产品</div>
      <div class="rec-tabs">${cats.map(([k,n]) => `<button class="${state.compareCat===k?"on":""}" data-act="cmp-cat" data-tab="${k}">${n}</button>`).join("")}</div>
      <div class="subtxt">产品A</div>
      <button class="field" style="width:100%" data-act="pick-prod" data-slot="A"><span class="picker ${a?"has":""}">${a ? esc(a.name) : "请选择产品名称或产品代码"}</span><span>›</span></button>
      <div class="subtxt" style="margin-top:8px">产品B</div>
      <button class="field" style="width:100%" data-act="pick-prod" data-slot="B"><span class="picker ${b?"has":""}">${b ? esc(b.name) : "请选择产品名称或产品代码"}</span><span>›</span></button>
      <button class="btn-primary" data-act="do-compare">查询</button>
    </article>`;
  }

  function renderWmCompare(a, b) {
    const tab = state.compareTab;
    const tabs = [["basic","基础信息"],["rule","交易规则"],["inv","投资方向"],["perf","历史业绩"]];
    let extra = "";
    if (tab === "basic") extra = `<h4 style="margin:8px 0">基础信息对比</h4>
      ${cmpTable(a,b,[["产品名称","name"],["产品代码","code"],["成立日期","found"],["成立币种","currency"],["风险等级","riskLabel"],["管理机构","org"],["开放类型","openType"],["持有期","rules"]])}`;
    if (tab === "rule") extra = `<p class="subtxt" style="line-height:1.6;margin-bottom:8px">${esc(HXZ.COMPARE_LIQ)}</p>
      <div class="block-title">买入规则</div>${cmpTable(a,b,[["确认份额时间","confirm"],["买入费率",null],["起购金额","minAmt"]])}
      <div class="block-title">卖出规则</div>${cmpTable(a,b,[["到账时间","redeemArrive"]])}`;
    if (tab === "inv") extra = `<p class="subtxt" style="line-height:1.6">${esc(HXZ.COMPARE_INV)}</p>
      <p class="subtxt" style="margin-top:8px">A：${(a.invest||[]).join("；")}</p><p class="subtxt">B：${(b.invest||[]).join("；")}</p>`;
    if (tab === "perf") extra = `<p class="subtxt" style="line-height:1.6">${esc(HXZ.COMPARE_PERF)}</p>
      <div class="tabs"><button class="on">区间涨跌幅</button><button>年化收益率</button></div>
      ${svgDual()}
      <div class="range"><button class="on">近1月</button><button>近3月</button><button>近6月</button><button>近1年</button><button>成立以来</button></div>`;
    const aWin = parseNum(a.yield) >= parseNum(b.yield);
    return `<article class="card">
      <div class="sum"><strong>怎么跟客户讲</strong>${esc(HXZ.COMPARE_SUMMARY)}</div>
      <div class="pk">
        <div class="side a ${aWin ? "win" : ""}"><div class="pn">${esc(a.name)}</div><div class="pc">${esc(a.code)}</div><div class="p-tags"><span class="ptag gray">理财</span><span class="ptag gray">${esc(a.org)}</span></div></div>
        <span class="vs">VS</span>
        <div class="side b ${aWin ? "" : "win"}"><div class="pn">${esc(b.name)}</div><div class="pc">${esc(b.code)}</div><div class="p-tags"><span class="ptag gray">理财</span><span class="ptag gray">${esc(b.org)}</span></div></div>
      </div>
      ${cmpBarRow(a.yield, "展示收益", b.yield)}
      ${cmpRow(a.riskLabel, "风险等级", b.riskLabel)}
      ${cmpRow(a.rules, "流动性", b.rules)}
      ${cmpRow(a.status, "销售状态", b.status)}
      <div class="tabs">${tabs.map(([k,n]) => `<button class="${tab===k?"on":""}" data-act="cmp-tab" data-tab="${k}">${n}</button>`).join("")}</div>
      ${extra}
    </article>`;
  }

  function cmpRow(l, m, r) {
    return `<div class="cmp-row"><div class="cr-top"><div class="cv">${esc(l)}</div><div class="mid">${esc(m)}</div><div class="cv">${esc(r)}</div></div></div>`;
  }
  function cmpTable(a, b, rows) {
    return `<table class="data"><tr><th></th><th>产品A</th><th>产品B</th></tr>${rows.map(([k,f]) => `<tr><td>${k}</td><td>${esc(f ? a[f] : "无")}</td><td>${esc(f ? b[f] : "无")}</td></tr>`).join("")}</table>`;
  }

  function renderFundCompare(a, b) {
    const av = a.monetary ? a.yield : a.daily, bv = b.monetary ? b.yield : b.daily;
    return `<article class="card">
      <div class="sum"><strong>怎么跟客户讲</strong>两只均为基金。货币看近7日年化，非货币看日涨幅，口径不要混着讲。</div>
      <div class="pk">
        <div class="side a"><div class="pn">${esc(a.name)}</div><div class="pc">${esc(a.code)}</div></div>
        <span class="vs">VS</span>
        <div class="side b"><div class="pn">${esc(b.name)}</div><div class="pc">${esc(b.code)}</div></div>
      </div>
      ${cmpBarRow(av, "核心收益", bv)}
      ${cmpRow(a.riskLabel, "风险等级", b.riskLabel)}
      ${cmpRow(a.status, "申赎状态", b.status)}
    </article>`;
  }

  function renderInsCompare(a, b) {
    return `<article class="card">
      ${cmpRow(a.name, "产品名称", b.name)}
      ${cmpRow(a.attr, "产品属性", b.attr)}
      ${cmpRow(a.payType, "缴费年期类型", b.payType)}
      ${cmpRow(a.payYears, "缴费期间", b.payYears)}
      ${cmpRow(a.coverType, "保障年期类型", b.coverType)}
      ${cmpRow(a.coverYears, "保险期间", b.coverYears)}
      ${cmpRow(a.riskLabel, "风险等级", b.riskLabel)}
    </article>`;
  }

  function renderTodoPicker() {
    const items = [["expire","产品到期"],["move","资产大幅变动"],["loan","贷款逾期"],["birthday","生日提醒"],["contact","联络超期提醒"],["card","信用卡待办"]];
    return `<article class="card"><div class="card-hd">请选择待办类型</div>
      <div class="grid2">${items.map(([k,n]) => `<button class="choice" data-act="todo" data-type="${k}">${n}</button>`).join("")}</div>
    </article>`;
  }

  function handleBtn(t) {
    if (t.handled) return `<span class="handle done">✓ 已处理</span>`;
    return `<button class="handle" data-act="handle" data-id="${t.id}">去处理</button>`;
  }

  function todoNext(type, t) {
    if (type === "loan") return `下一步：先核实 ${t.due} 还款情况，再决定电话还是上门。`;
    if (type === "expire") return "下一步：先确认是否续存，再配期限匹配的承接产品。";
    if (type === "move") return t.delta >= 0 ? "下一步：核实资金来源，评估能否留存或配置。" : "下一步：核实资金去向，判断流失风险。";
    if (type === "birthday") return "下一步：轻触达即可，可结合权益或生日礼。";
    if (type === "contact") return "下一步：补一次电话，避免关系降温。";
    if (type === "card") return `下一步：处理「${t.biz}」。`;
    return "";
  }

  function renderTodoList(type) {
    const titles = { expire:"产品到期", move:"上日大额异动", loan:"贷款逾期", birthday:"生日提醒", contact:"联络超期提醒", card:"信用卡待办" };
    let items = [...(HXZ.TODOS[type] || [])].sort((a, b) => (a.handled ? 1 : 0) - (b.handled ? 1 : 0));
    if (!items.length) return `<article class="card"><div class="empty"><span class="star">☆</span>今日暂无该类待办</div></article>`;
    const cards = items.map((t) => {
      const c = cust(t.custId);
      if (!c) return "";
      let body = "";
      if (type === "expire") body = t.products.map((p) => `<div class="t-metrics" style="grid-template-columns:1fr 1fr"><div><div class="n">${esc(p.amt)}</div><div class="lab">${esc(p.name)} · 金额</div></div><div><div class="n red">${esc(p.date)}</div><div class="lab">到期日期</div></div></div>`).join("");
      if (type === "move") body = `<div class="t-metrics" style="grid-template-columns:1fr 1fr"><div><div class="n">${esc(t.bal)}</div><div class="lab">当前余额</div></div><div><div class="n ${t.delta>=0?"red":"green"}">${t.delta>=0?"+":""}${t.delta.toLocaleString()}.00元</div><div class="lab">上日异动金额</div></div></div>`;
      if (type === "loan") body = `<div class="subtxt" style="margin-top:8px">${esc(t.name)}</div><div class="t-metrics"><div><div class="n">${esc(t.overdueAmt)}</div><div class="lab">逾期金额</div></div><div><div class="n">${esc(t.times)}</div><div class="lab">逾期次数</div></div><div><div class="n red">${esc(t.due)}</div><div class="lab">还款日期</div></div></div>`;
      if (type === "birthday") body = `<div class="t-metrics" style="grid-template-columns:1fr 1fr"><div><div class="n">${esc(t.birth)}</div><div class="lab">出生日期</div></div><div><div class="n red">${t.left===0?"今天":t.left+"天"}</div><div class="lab">距离生日还有</div></div></div>`;
      if (type === "contact") body = `<div class="t-metrics"><div><div class="n">${esc(t.aum)}</div><div class="lab">总资产余额</div></div><div><div class="n">${esc(t.last)}</div><div class="lab">最后联络日期</div></div><div><div class="n red">${t.days}天</div><div class="lab">超期天数</div></div></div>`;
      if (type === "card") body = `<div class="t-metrics" style="grid-template-columns:1fr 1fr"><div><div class="n" style="font-size:14px">${esc(t.acct)}</div><div class="lab">信用卡账号</div></div><div><div class="n" style="font-size:14px">${esc(t.biz)}</div><div class="lab">业务类型</div></div></div>`;
      const hint = todoNext(type, t);
      return `<div class="t-card">
        <div class="t-top">
          <button data-act="open-portrait" data-id="${c.id}" style="flex:1;text-align:left">${personLine({...c, phone:""})}</button>
          ${type === "contact" ? "" : handleBtn(t)}
        </div>${body}${hint ? `<p class="next-hint">${esc(hint)}</p>` : ""}</div>`;
    }).join("");
    return `<article class="card"><div class="card-hd"><b>${titles[type]}</b><div class="subtxt" style="margin-top:4px">${items.length} 位客户待跟进 · 点姓名看怎么谈</div></div>${cards}<button class="btn-ghost">查看全部</button></article>`;
  }

  function renderYday() {
    const rate = parseFloat(HXZ.YDAY.rate) || 0;
    return `<article class="card">
      <div class="card-hd"><b>昨日完成情况</b></div>
      <div class="ring-row" style="cursor:default;margin-top:0">${ring(rate)}<span class="rr-t"><b>${HXZ.YDAY.rate}</b><span>待办完成率</span></span></div>
      <table class="data"><tr><th>类型</th><th>已处理 / 总共</th></tr>
      ${HXZ.YDAY.rows.map((r) => `<tr><td>${r.k}</td><td>${r.done} / ${r.total}</td></tr>`).join("")}</table>
    </article>`;
  }

  function renderOppPicker() {
    return `<article class="card"><div class="card-hd">请选择商机类型</div>
      <div class="grid2"><button class="choice" data-act="payroll">代发商机</button><button class="choice" data-act="churn">流失预警</button></div>
    </article>`;
  }

  function renderPayroll() {
    return `<article class="card"><div class="card-hd"><b>代发即将到账名单（未来7天）</b></div>
      ${HXZ.PAYROLL.map((x) => { const c = cust(x.custId); if (!c) return ""; return `<div class="t-card"><button data-act="open-portrait" data-id="${c.id}" style="width:100%;text-align:left">${personLine({...c,phone:""})}</button>
        <div class="t-metrics" style="grid-template-columns:1fr 1fr"><div><div class="n">${esc(x.avg)}</div><div class="lab">近6月月均代发平均金额</div></div>
        <div><div class="n red">${esc(x.last)}</div><div class="lab">最近1次代发日期</div></div></div></div>`; }).join("")}
    </article>`;
  }

  function renderChurn() {
    return `<article class="card"><div class="card-hd"><b>流失预警名单</b></div>
      ${HXZ.CHURN.map((x) => { const c = cust(x.custId); if (!c) return ""; return `<div class="t-card"><button data-act="open-portrait" data-id="${c.id}" style="width:100%;text-align:left">${personLine({...c,phone:""})}</button>
        <div class="t-metrics"><div><div class="n">${esc(x.aum)}</div><div class="lab">资产金额</div></div>
        <div><div class="n">${esc(x.level)}</div><div class="lab">客户等级</div></div>
        <div><div class="n ${x.prob>=70?"red":""}">${x.prob}%</div><div class="lab">流失概率</div></div></div></div>`; }).join("")}
    </article>`;
  }

  function renderNews() {
    return `<article class="card">
      <div class="card-hd"><b>今日市场简报</b></div>
      ${HXZ.NEWS.points.map((p, i) => `<div class="np"><i>${i + 1}</i><span>${esc(p)}</span></div>`).join("")}
      <div class="insight" style="margin-top:10px"><div class="ins-lab">展业提示</div><p>${esc(HXZ.NEWS.tip)}</p></div>
      <p class="note">内部参考，对客话术须同步揭示风险。</p>
    </article>`;
  }

  function renderScript(text, style) {
    return `<div class="bubble-ai"><div class="script">${esc(text)}</div>
      <div class="script-acts"><button data-act="copy" data-text="${esc(text)}">复制</button>
      ${style === "pro" ? "" : `<button data-act="style-pro">生成专业化版本</button>`}
      ${style === "pro" ? `<button data-act="style-casual">生成口语化版本</button>` : ""}
      </div></div>`;
  }

  function renderCard(m) {
    const p = m.payload || {};
    switch (m.type) {
      case "custq": return renderCustQuery();
      case "custlist": return renderCustList(p.ids, p.mode);
      case "portrait": return renderPortrait(cust(p.id), p);
      case "prodq": return renderProdQuery();
      case "prodlist": return renderProdList(p.list, p.showAll, p.mode);
      case "wm": return renderWmDetail(p.prod);
      case "fund": return renderFundDetail(p.prod);
      case "ins": return renderInsDetail(p.prod);
      case "cmpentry": return renderCompareEntry();
      case "wmcmp": return renderWmCompare(p.a, p.b);
      case "fundcmp": return renderFundCompare(p.a, p.b);
      case "inscmp": return renderInsCompare(p.a, p.b);
      case "todopick": return renderTodoPicker();
      case "todolist": return renderTodoList(p.type);
      case "yday": return renderYday();
      case "opppick": return renderOppPicker();
      case "payroll": return renderPayroll();
      case "churn": return renderChurn();
      case "news": return renderNews();
      default: return "";
    }
  }

  function renderMessage(m) {
    if (m.kind === "home") return renderHome();
    if (m.kind === "user") return `<div class="bubble-user">${esc(m.text)}</div>`;
    if (m.kind === "meta") return `<div class="meta">${esc(m.text)}</div>`;
    if (m.kind === "ai") return `<div class="bubble-ai">${esc(m.text)}</div>`;
    if (m.kind === "script") return renderScript(m.text, m.style);
    if (m.kind === "card") return renderCard(m);
    return "";
  }

  /* overlays */
  function overlayHTML() {
    const o = state.overlay;
    if (o === "history") {
      return `<div class="overlay">
        <header class="nav"><button class="nav-btn" data-act="close-ov">‹</button><div class="nav-title"><strong>历史会话</strong></div><button class="nav-btn" data-act="new-session">＋</button></header>
        <div style="overflow:auto;flex:1">
          ${state.sessions.map((s) => `<button class="hist-item" data-act="open-session" data-id="${s.id}" style="width:100%;text-align:left"><b>${esc(s.title)}</b><span class="subtxt">${esc(s.time)} · ${esc(s.preview)}</span></button>`).join("") || `<div class="empty">暂无历史对话</div>`}
        </div>
      </div>`;
    }
    if (o === "save") {
      return `<div class="overlay">
        <header class="nav"><button class="nav-btn" data-act="close-ov">‹</button><div class="nav-title"><strong>保存客群</strong></div><span style="width:40px"></span></header>
        <div style="padding:12px 16px;overflow:auto;flex:1">
          <div class="card">
            <div class="field"><label><i class="req">*</i>客群名称</label><input id="gname" maxlength="30" placeholder="请输入客群名称" value="${esc(state.saveForm.name)}" /></div>
            <button class="field" style="width:100%" data-act="pick-enum" data-enum="biz"><label><i class="req">*</i>业务类型</label><span class="picker ${state.saveForm.biz?"has":""}" id="gbiz" data-v="${esc(state.saveForm.biz)}">${state.saveForm.biz ? esc(state.saveForm.biz)+" ›" : "请选择业务类型 ›"}</span></button>
            <button class="field" style="width:100%" data-act="pick-enum" data-enum="goal"><label><i class="req">*</i>营销目的</label><span class="picker ${state.saveForm.goal?"has":""}" id="ggoal" data-v="${esc(state.saveForm.goal)}">${state.saveForm.goal ? esc(state.saveForm.goal)+" ›" : "请选择营销目的 ›"}</span></button>
            <div class="field"><label><i class="req">*</i>有效期</label><input id="gend" type="date" min="${HXZ.TODAY}" value="${esc(state.saveForm.end)}" /></div>
          </div>
          <p class="subtxt" style="margin:12px 4px">温馨提示：每个客群最多保存前10000名客户</p>
          <div class="duo-btn"><button class="btn-outline" data-act="close-ov">取消</button><button class="btn-primary" style="margin-top:0" data-act="do-save">保存</button></div>
        </div>
      </div>`;
    }
    return "";
  }

  function maskHTML() {
    if (state.sheet === "summary") {
      return `<div class="mask center" data-act="close-sheet"><div class="modal" data-stop="1">
        <button class="close-x" data-act="close-sheet">×</button>
        <h3>昨日工作总结</h3>
        <h4 style="font-size:14px;margin:8px 0">一、昨日工作完成情况</h4>
        ${HXZ.YDAY.rows.map((r) => `<p style="font-size:14px;line-height:1.7">${r.k}：共 ${r.total}，已处理 ${r.done}，完成率 ${(r.done/r.total*100).toFixed(2)}%，剩余 ${r.total-r.done} 条待${r.restHint}。</p>`).join("")}
        <h4 style="font-size:14px;margin:12px 0 8px">二、工作亮点</h4>
        <p style="font-size:13px;line-height:1.7">${esc(HXZ.YDAY.highlight)}</p>
        <h4 style="font-size:14px;margin:12px 0 8px">三、存在问题</h4>
        <p style="font-size:13px;line-height:1.7">${esc(HXZ.YDAY.problem)}</p>
      </div></div>`;
    }
    if (state.sheet === "wealth") {
      return `<div class="mask center" data-act="close-sheet"><div class="modal" data-stop="1">
        <h3>财富潜在分说明</h3>
        <p style="font-size:13px;line-height:1.7">根据三个评分维度（资产配置维度、收入稳定性维度、社会身份与资源维度）综合计算得出，仅用于内部服务匹配参考。得分越高，代表客户越适配我行高净值服务体系，可优先为其匹配专属服务资源。</p>
        <button class="btn-primary" data-act="close-sheet">我知道了</button>
      </div></div>`;
    }
    if (state.sheet === "yield") {
      return `<div class="mask center" data-act="close-sheet"><div class="modal" data-stop="1">
        <h3>收益率解释说明</h3>
        <p style="font-size:13px;line-height:1.7">成立以来年化收益率按产品净值计算。近7日年化仅适用于现金管理类。过往业绩不代表未来表现。</p>
        <button class="btn-primary" data-act="close-sheet">我知道了</button>
      </div></div>`;
    }
    if (state.sheet === "more-cust") {
      return `<div class="mask" data-act="close-sheet"><div class="sheet" data-stop="1">
        <h3>更多筛选条件</h3>
        ${rowChips("年龄", ["<30","30–45","45–60","60+"], "age")}
        ${rowChips("性别", ["男","女"], "gender")}
        ${rowChips("客户等级", ["万元户","优质","财富","高净值"], "level")}
        <button class="btn-primary" data-act="close-sheet">确定</button>
      </div></div>`;
    }
    if (state.sheet === "more-prod") {
      const extra = state.prodCat === "wm"
        ? rowChips("明星产品", ["是","否"], "star") + rowChips("币种", ["人民币","美元","港元"], "cur") + rowChips("管理机构", ["安鑫理财","兴银理财","杭银理财","苏银理财"], "org")
        : rowChips("热度", ["近1周浏览量前十","近1周搜索量前十"], "hot");
      return `<div class="mask" data-act="close-sheet"><div class="sheet" data-stop="1"><h3>更多筛选条件</h3>${extra}<button class="btn-primary" data-act="close-sheet">确定</button></div></div>`;
    }
    if (state.sheet === "pick-prod") {
      const list = HXZ.PRODUCTS[state.compareCat] || [];
      return `<div class="mask" data-act="close-sheet"><div class="sheet" data-stop="1">
        <h3>选择产品</h3>
        ${list.map((p) => `<button class="cust-row" style="width:100%;text-align:left" data-act="choose-prod" data-id="${p.id}"><div class="cust-main"><strong>${esc(p.name)}</strong><div class="idline">${esc(p.code)}</div></div></button>`).join("")}
      </div></div>`;
    }
    if (state.sheet === "enum-biz" || state.sheet === "enum-goal") {
      const biz = ["个金条线","信用卡条线","移动金融条线","个贷条线","网贷条线","财富条线"];
      const goal = ["潜客挖掘","产品提升","服务优化","福利发放","营销活动"];
      const list = state.sheet === "enum-biz" ? biz : goal;
      const key = state.sheet === "enum-biz" ? "biz" : "goal";
      return `<div class="mask" data-act="close-sheet"><div class="sheet" data-stop="1">
        <h3>${key==="biz"?"业务类型":"营销目的"}</h3>
        ${list.map((x) => `<button class="cust-row" style="width:100%;text-align:left" data-act="choose-enum" data-key="${key}" data-v="${x}"><strong>${x}</strong></button>`).join("")}
      </div></div>`;
    }
    return "";
  }

  function render() {
    $("#device").className = "device app";
    $("#stream").innerHTML = state.session.messages.map(renderMessage).join("");
    $("#overlayRoot").innerHTML = overlayHTML() + maskHTML();
    const clearWrap = $("#clearWrap");
    if (clearWrap) {
      clearWrap.hidden = state.session.messages.length <= 1;
      const btn = $("#clearBtn");
      if (btn && clearWrap.hidden) { btn.dataset.confirm = ""; btn.textContent = "清空会话"; btn.classList.remove("confirm"); }
    }
  }

  function clearChat(btn) {
    if (btn.dataset.confirm !== "1") {
      btn.dataset.confirm = "1";
      btn.textContent = "再点一次确认清空";
      btn.classList.add("confirm");
      setTimeout(() => { btn.dataset.confirm = ""; btn.textContent = "清空会话"; btn.classList.remove("confirm"); }, 3000);
      return;
    }
    const s = state.session;
    s.messages = [{ id: uid(), kind: "home" }];
    s.title = "新对话";
    s.preview = "欢迎使用易小助";
    s.hasInteracted = false;
    state.brandOn = true;
    state.currentCustomer = null;
    state.currentProduct = null;
    state.lastScript = null;
    state.lastIntent = null;
    render();
    $("#stream").scrollTo(0, 0);
    toast("已清空当前会话");
  }

  /* ——— actions ——— */
  function openPortrait(id) {
    const c = cust(id);
    if (!c) return addAI("未查询到该客户，请确认是否为您的管户客户。");
    state.currentCustomer = c;
    state.lastScript = { kind: "opening", style: "casual" };
    state.recTab = "wm";
    addCard("portrait", { id, recTab: "wm" });
  }

  function openProduct(p) {
    state.currentProduct = p;
    if (p.type === "wm") addCard("wm", { prod: p });
    else if (p.type === "fund") addCard("fund", { prod: p });
    else addCard("ins", { prod: p });
  }

  function findProducts(key, cat) {
    const pool = cat ? HXZ.PRODUCTS[cat] : [...HXZ.PRODUCTS.wm, ...HXZ.PRODUCTS.fund, ...HXZ.PRODUCTS.ins];
    const k = (key || "").trim();
    if (!k) return pool;
    return pool.filter((p) => p.name.includes(k) || p.code.toLowerCase().includes(k.toLowerCase()));
  }

  async function runCustQueryFromCard(card) {
    const name = $("[data-f=name]", card)?.value.trim() || "";
    const cid = $("[data-f=cid]", card)?.value.trim() || "";
    const mobile = $("[data-f=mobile]", card)?.value.trim() || "";
    if (state.custQueryTab === "search" && !name && !cid && !mobile && !$("[data-f=idno]", card)?.value.trim()) {
      toast("请至少输入一项查询条件");
      return;
    }
    if (mobile && (!/^\d{11}$/.test(mobile) || /(\d)\1{9}/.test(mobile))) {
      toast("客户手机号应为11位数字，且不得为连续10位重复数字");
      return;
    }
    if (name && /[A-Za-z]/.test(name)) {
      toast("姓名仅支持汉字");
      return;
    }
    await withQuery(() => {
      let list = HXZ.CUSTOMERS.slice();
      if (name) list = list.filter((c) => c.name.includes(name));
      if (cid) list = list.filter((c) => c.id === cid);
      if (mobile) list = list.filter((c) => c.phone.replace(/\*/g, "") === mobile.replace(/\*/g, "") || mobile.startsWith(c.phone.slice(0, 3)));
      if (state.custQueryTab === "filter") {
        if (state.filters.groups === "代发客群") list = list.filter((c) => c.tags.includes("代发客群") || /月均代发/.test(c.behavior.payroll));
        if (state.filters.groups === "到期承接池") list = list.filter((c) => ["100017", "100019"].includes(c.id));
        if (state.filters.groups === "高净值潜力") list = list.filter((c) => c.tags.includes("高净值关注") || c.wealthScore >= 80);
        if (state.filters.holds.length) {
          list = list.filter((c) => state.filters.holds.some((h) => {
            if (["理财", "基金", "保险"].includes(h)) return c.holding.slices.some((s) => s.k === h && s.v > 0);
            if (h === "消费贷") return c.credit?.loans?.some((l) => l.name.includes("消费"));
            if (h === "经营贷") return c.credit?.loans?.some((l) => l.name.includes("经营"));
            if (h === "房贷") return c.credit?.loans?.some((l) => /房|按揭/.test(l.name));
            return false;
          }));
        }
        const ages = state.filters.age || [];
        if (ages.length) {
          list = list.filter((c) => ages.some((a) => (a === "<30" && c.age < 30) || (a === "30–45" && c.age >= 30 && c.age <= 45) || (a === "45–60" && c.age > 45 && c.age <= 60) || (a === "60+" && c.age >= 60)));
        }
        const genders = state.filters.gender || [];
        if (genders.length) list = list.filter((c) => genders.includes(c.gender));
        const levels = state.filters.level || [];
        if (levels.length) list = list.filter((c) => levels.some((l) => c.level.includes(l)));
      }
      if (!list.length) addAI("未在您的管户范围内找到符合条件的客户，请更换条件后再试。");
      else if (list.length === 1) openPortrait(list[0].id);
      else addCard("custlist", { ids: list.map((c) => c.id), mode: state.lastIntent === "script" ? "clarify" : "list" });
    });
  }

  async function runProdQueryFromCard(card) {
    if (state.prodQueryTab === "search") {
      const k = $("[data-f=pkey]", card)?.value.trim() || "";
      if (!k) { toast("请输入产品名称或代码"); return; }
      await withQuery(() => {
        const hit = findProducts(k);
        if (!hit.length) addAI("抱歉，未查询到符合条件的产品");
        else if (hit.length === 1) openProduct(hit[0]);
        else addCard("prodlist", { list: hit });
      });
      return;
    }
    await withQuery(() => {
      let list = HXZ.PRODUCTS[state.prodCat].slice();
      const klass = state.filters.fundKlass || [];
      if (klass.length) list = list.filter((p) => klass.some((x) => (p.klass || "").includes(x.replace("型","")) || p.klass === x));
      const wmCat = state.filters.wmCat || [];
      if (wmCat.length) list = list.filter((p) => wmCat.includes(p.cat) || wmCat.includes("固定期限") && p.cat === "固定期限");
      if (!list.length) addAI("抱歉，未查询到符合条件的产品");
      else if (list.length === 1) openProduct(list[0]);
      else addCard("prodlist", { list });
    });
  }

  async function handleSend(raw) {
    const text = raw.trim();
    if (!text || state.busy) return;
    addUser(text);
    $("#input").value = "";
    $("#sendBtn").disabled = true;
    $("#suggest").classList.remove("show");

    const t = text.replace(/\s/g, "");
    if (/政治|暴力|色情/.test(t)) { addAI("该问题我暂时无法回答，请换个展业相关的问题。"); return; }

    if (/待办完成|昨日待办|昨日完成/.test(t)) { await withQuery(() => addCard("yday")); return; }
    if (/工作总结/.test(t)) { state.sheet = "summary"; render(); return; }
    if (/我有什么待办|今日待办|我的待办|^待办$/.test(t)) { await withQuery(() => addCard("todopick")); return; }
    if (/产品到期|承接名单/.test(t)) { await withQuery(() => addCard("todolist", { type: "expire" })); return; }
    if (/大额异动|大额入金|大额出金/.test(t)) { await withQuery(() => addCard("todolist", { type: "move" })); return; }
    if (/贷款逾期/.test(t)) { await withQuery(() => addCard("todolist", { type: "loan" })); return; }
    if (/生日/.test(t)) { await withQuery(() => addCard("todolist", { type: "birthday" })); return; }
    if (/联络超期/.test(t)) { await withQuery(() => addCard("todolist", { type: "contact" })); return; }
    if (/信用卡/.test(t)) { await withQuery(() => addCard("todolist", { type: "card" })); return; }

    if (/商机有什么|^商机$|我的商机/.test(t)) { await withQuery(() => addCard("opppick")); return; }
    if (/代发/.test(t)) { await withQuery(() => addCard("payroll")); return; }
    if (/流失/.test(t)) { await withQuery(() => addCard("churn")); return; }
    if (/资讯|简报|行情/.test(t)) { await withQuery(() => addCard("news")); return; }

    if (/专业化|专业版/.test(t)) { styleSwitch("pro"); return; }
    if (/口语化|白话/.test(t)) { styleSwitch("casual"); return; }

    if (/对比|PK|有什么差别/.test(t)) {
      const uniq = productHits(t);
      if (uniq.length >= 3) { addAI("一次仅支持对比 2 只产品，请重新提问。"); return; }
      if (uniq.length === 1) { addAI("请再提供另 1 只同类型产品。"); state.compareA = uniq[0]; state.compareB = null; state.compareCat = uniq[0].type; addCard("cmpentry"); return; }
      if (uniq.length === 2) {
        if (uniq[0].type !== uniq[1].type) {
          addAI("两只产品类型不同，已分别为您展示详情，不生成对比表。");
          openProduct(uniq[0]); openProduct(uniq[1]); return;
        }
        await withQuery(() => {
          state.currentProduct = uniq[0];
          if (uniq[0].type === "wm") addCard("wmcmp", { a: uniq[0], b: uniq[1] });
          else if (uniq[0].type === "fund") addCard("fundcmp", { a: uniq[0], b: uniq[1] });
          else addCard("inscmp", { a: uniq[0], b: uniq[1] });
        });
        return;
      }
      if (/黄金|存款|国债|信托/.test(t) && !/理财|基金|保险/.test(t)) { addAI("暂不支持该类型，目前可查询和对比理财、基金、保险。"); return; }
      state.compareA = state.compareB = null;
      addCard("cmpentry");
      return;
    }

    if (/开场白|打招呼|怎么和|怎么谈/.test(t)) {
      const c = HXZ.CUSTOMERS.find((x) => t.includes(x.name)) || state.currentCustomer;
      if (!c) { state.lastIntent = "script"; addAI("您好，请输入具体客户信息"); addCard("custq"); return; }
      await withQuery(() => {
        state.currentCustomer = c;
        state.lastScript = { kind: "opening", style: "casual" };
        push({ id: uid(), kind: "script", text: openingScript(c, "casual"), style: "casual" });
      });
      return;
    }

    if (/话术|怎么讲|怎么卖|推销|营销卖点/.test(t)) {
      if (/权益/.test(t)) {
        state.lastScript = { kind: "right", style: "casual" };
        push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.rightCasual, style: "casual" });
        return;
      }
      if (/活动/.test(t)) {
        state.lastScript = { kind: "act", style: "casual" };
        push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.activityCasual, style: "casual" });
        return;
      }
      const hits = productHits(t);
      if (hits.length > 1) {
        addAI("查询到多个产品，请确认是哪一个");
        addCard("prodlist", { list: hits, mode: "clarify" });
        return;
      }
      const p = hits[0];
      if (!p && !state.currentProduct) { addAI("您好，请输入具体产品信息"); addCard("prodq"); return; }
      const use = p || state.currentProduct;
      state.currentProduct = use;
      state.lastScript = { kind: "product", style: "casual" };
      await withQuery(() => push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.productCasual, style: "casual" }));
      return;
    }

    const named = customerHits(t);
    if (/画像|查(一下)?客户|查询客户|找客户/.test(t) || named.length || /张三|李四|非管户/.test(t)) {
      if (named.length === 1) { await withQuery(() => openPortrait(named[0].id)); return; }
      if (named.length > 1) { await withQuery(() => addCard("custlist", { ids: named.map((c) => c.id), mode: state.lastIntent === "script" ? "clarify" : "list" })); return; }
      if (/非管户/.test(t)) { await withQuery(() => addAI("未查询到该客户，请确认是否为您的管户客户。")); return; }
      if (/张三|李四/.test(t)) {
        await withQuery(() => addAI("未在您的管户范围内找到符合条件的客户，请更换条件后再试。"));
        return;
      }
      const rest = t.replace(/^查(一下)?/, "").replace(/^客户/, "");
      if (/^[\u4e00-\u9fa5]{1,4}$/.test(rest) && !/产品|理财|基金|保险|待办|商机|资讯|客户/.test(rest)) {
        await withQuery(() => addAI("未在您的管户范围内找到符合条件的客户，请更换条件后再试。"));
        return;
      }
      addCard("custq");
      return;
    }

    if (/查(一下)?(理财|基金|保险|产品)|产品筛选|有没有/.test(t) || /安盈|恒源|货币|金吉利|余额宝|祥盈|臻享|鑫如意|日添利/.test(t)) {
      if (/黄金|存款产品/.test(t) && !/理财|基金|保险/.test(t)) { addAI("暂不支持该类型，目前可查询和对比理财、基金、保险。"); return; }
      const namedProd = productHits(t);
      if (namedProd.length) {
        await withQuery(() => {
          if (namedProd.length === 1) openProduct(namedProd[0]);
          else addCard("prodlist", { list: namedProd, mode: "clarify" });
        });
        return;
      }
      if (/^查理财$|理财筛选/.test(t)) { state.prodCat = "wm"; state.prodQueryTab = "filter"; addCard("prodq"); return; }
      if (/基金/.test(t)) { state.prodCat = "fund"; state.prodQueryTab = "filter"; addCard("prodq"); return; }
      if (/保险/.test(t)) { state.prodCat = "ins"; state.prodQueryTab = "filter"; addCard("prodq"); return; }
      addCard("prodq");
      return;
    }

    addAI("我可以帮您查客户、查产品、做对比、看待办和商机，也可以生成话术。请试着说「查一下客户」或「我有什么待办」。");
  }

  function styleSwitch(to) {
    if (!state.lastScript) { addAI("请先生成一段话术，再切换风格。"); return; }
    const map = {
      opening: { casual: openingScript(state.currentCustomer, "casual"), pro: openingScript(state.currentCustomer, "pro") },
      product: { casual: HXZ.SCRIPTS.productCasual, pro: HXZ.SCRIPTS.productPro },
      right: { casual: HXZ.SCRIPTS.rightCasual, pro: HXZ.SCRIPTS.rightCasual },
      act: { casual: HXZ.SCRIPTS.activityCasual, pro: HXZ.SCRIPTS.activityCasual }
    };
    const pack = map[state.lastScript.kind] || map.product;
    state.lastScript.style = to;
    push({ id: uid(), kind: "script", text: pack[to], style: to });
  }

  function onClick(e) {
    const stop = e.target.closest("[data-stop]");
    const actEl = e.target.closest("[data-act]");
    if (e.target.closest(".mask") && !stop && e.target.classList.contains("mask")) {
      state.sheet = null; render(); return;
    }
    if (!actEl) return;
    const act = actEl.dataset.act;
    const ds = actEl.dataset;

    if (act === "chip") { handleSend(ds.text); return; }
    if (act === "voice") { toast("原型演示请使用文字输入"); return; }
    if (act === "back-yzk") { toast("将返回易知客工作台（原型不跳转）"); return; }
    if (act === "open-history") { state.overlay = "history"; render(); return; }
    if (act === "close-ov") { state.overlay = null; render(); return; }
    if (act === "close-sheet") { state.sheet = null; render(); return; }
    if (act === "new-session") { newSession(); state.overlay = null; render(); scrollEnd(); return; }
    if (act === "clear-chat") { clearChat(e.target.closest("button")); return; }
    if (act === "open-session") {
      state.session = state.sessions.find((s) => s.id === ds.id) || state.session;
      state.overlay = null; state.brandOn = !state.session.hasInteracted; render(); return;
    }
    if (act === "todo") { addUser("查看" + ({expire:"产品到期",move:"资产大幅变动",loan:"贷款逾期",birthday:"生日提醒",contact:"联络超期提醒",card:"信用卡待办"}[ds.type])); withQuery(() => addCard("todolist", { type: ds.type })); return; }
    if (act === "yday-rate") { addUser("昨日待办完成情况"); withQuery(() => addCard("yday")); return; }
    if (act === "yday-sum") { state.sheet = "summary"; render(); return; }
    if (act === "payroll") { addUser("代发商机名单"); withQuery(() => addCard("payroll")); return; }
    if (act === "churn") { addUser("流失预警名单"); withQuery(() => addCard("churn")); return; }
    if (act === "news") { addUser("今日资讯"); withQuery(() => addCard("news")); return; }
    if (act === "open-cust") { addCard("custq"); return; }
    if (act === "open-prod") { state.prodQueryTab = "filter"; addCard("prodq"); return; }
    if (act === "cust-tab") { state.custQueryTab = ds.tab; render(); return; }
    if (act === "prod-tab") { state.prodQueryTab = ds.tab; render(); return; }
    if (act === "prod-cat") { state.prodCat = ds.tab; render(); return; }
    if (act === "cmp-cat") { state.compareCat = ds.tab; state.compareA = state.compareB = null; render(); return; }
    if (act === "cmp-tab") { state.compareTab = ds.tab; render(); return; }
    if (act === "rec-tab") {
      state.recTab = ds.tab;
      const last = [...state.session.messages].reverse().find((m) => m.kind === "card" && m.type === "portrait");
      if (last) last.payload.recTab = ds.tab;
      render(); return;
    }
    if (act === "jump") {
      const card = actEl.closest(".person-card");
      const sec = card?.querySelector(`[data-sec="${ds.to}"]`);
      const stream = $("#stream");
      if (sec && stream) {
        const top = sec.getBoundingClientRect().top - stream.getBoundingClientRect().top + stream.scrollTop;
        stream.scrollTop = Math.max(0, top - 8);
      }
      if (card) $$(".anchors button", card).forEach((b) => b.classList.toggle("on", b.dataset.to === ds.to));
      return;
    }
    if (act === "expand-prod") {
      const last = [...state.session.messages].reverse().find((m) => m.kind === "card" && m.type === "prodlist");
      if (last) last.payload.showAll = true;
      render(); return;
    }
    if (act === "fund-tab") { state.fundTab = ds.tab; render(); return; }
    if (act === "wm-tab") { state.wmTab = ds.tab; render(); return; }
    if (act === "range") { state.range = ds.tab; render(); return; }
    if (act === "chip-group") { state.filters.groups = state.filters.groups === ds.v ? "" : ds.v; render(); return; }
    if (act === "chip-hold") {
      const arr = state.filters.holds;
      const i = arr.indexOf(ds.v); if (i >= 0) arr.splice(i,1); else arr.push(ds.v);
      render(); return;
    }
    if (act === "chip-multi") {
      const arr = state.filters[ds.key] || (state.filters[ds.key] = []);
      const i = arr.indexOf(ds.v); if (i >= 0) arr.splice(i,1); else arr.push(ds.v);
      render(); return;
    }
    if (act === "more-cust") { state.sheet = "more-cust"; render(); return; }
    if (act === "more-prod") { state.sheet = "more-prod"; render(); return; }
    if (act === "do-cust-query") { runCustQueryFromCard(actEl.closest("[data-card]")); return; }
    if (act === "do-prod-query") { runProdQueryFromCard(actEl.closest("[data-card]")); return; }
    if (act === "open-portrait") { withQuery(() => openPortrait(ds.id)); return; }
    if (act === "open-prod-id") { const p = product(ds.id); if (p) withQuery(() => openProduct(p)); return; }
    if (act === "save-group") { state.overlay = "save"; render(); return; }
    if (act === "do-save") {
      state.saveForm.name = $("#gname")?.value.trim() || "";
      const name = state.saveForm.name;
      const biz = state.saveForm.biz;
      const goal = state.saveForm.goal;
      const end = $("#gend")?.value || state.saveForm.end;
      state.saveForm.end = end;
      if (!name) return toast("请输入客群名称");
      if (!biz) return toast("请选择业务类型");
      if (!goal) return toast("请选择营销目的");
      if (!end) return toast("请选择结束日期");
      state.overlay = null;
      state.saveForm = { name: "", biz: "", goal: "", end: "" };
      render();
      toast("保存成功：已成功保存客群至易知客系统");
      return;
    }
    if (act === "pick-enum") {
      state.saveForm.name = $("#gname")?.value.trim() || state.saveForm.name;
      state.saveForm.end = $("#gend")?.value || state.saveForm.end;
      state.sheet = "enum-" + ds.enum; render(); return;
    }
    if (act === "choose-enum") {
      if (ds.key === "biz") state.saveForm.biz = ds.v;
      else state.saveForm.goal = ds.v;
      state.sheet = null; render();
      return;
    }
    if (act === "handle") {
      Object.values(HXZ.TODOS).flat().forEach((t) => { if (t.id === ds.id) t.handled = true; });
      toast("处理成功");
      render();
      return;
    }
    if (act === "wealth-tip") { state.sheet = "wealth"; render(); return; }
    if (act === "yield-tip") { state.sheet = "yield"; render(); return; }
    if (act === "copy") { navigator.clipboard?.writeText(ds.text || "").catch(() => {}); toast("已复制话术"); return; }
    if (act === "style-pro") {
      if (ds.from === "opening") state.lastScript = { kind: "opening", style: "casual" };
      addUser("生成专业化版本"); styleSwitch("pro"); return;
    }
    if (act === "style-casual") { addUser("生成口语化版本"); styleSwitch("casual"); return; }
    if (act === "prod-script") {
      const p = product(ds.id); state.currentProduct = p || state.currentProduct;
      state.lastScript = { kind: "product", style: "casual" };
      addUser("生成产品介绍话术");
      push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.productCasual, style: "casual" });
      return;
    }
    if (act === "right-script") {
      state.lastScript = { kind: "right", style: "casual" };
      push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.rightCasual, style: "casual" }); return;
    }
    if (act === "act-script") {
      state.lastScript = { kind: "act", style: "casual" };
      push({ id: uid(), kind: "script", text: HXZ.SCRIPTS.activityCasual, style: "casual" }); return;
    }
    if (act === "dep-script") {
      state.lastScript = { kind: "product", style: "casual" };
      push({ id: uid(), kind: "script", text: "添金喜个人结构性存款25213期是一只中低风险产品，主要投资固收类资产，属于稳中求进类型。产品 10,000元起购，业绩比较基准 2.059–2.65%。封闭型锁定未来三年收益，也避免频繁申赎成本。\n\n过往业绩不代表未来表现，请以产品合同为准。", style: "casual" });
      return;
    }
    if (act === "stars") {
      addCard("prodlist", { list: HXZ.PRODUCTS.wm.filter((p) => p.star) });
      return;
    }
    if (act === "pick-prod") { state.pickTarget = ds.slot; state.sheet = "pick-prod"; render(); return; }
    if (act === "choose-prod") {
      const p = (HXZ.PRODUCTS[state.compareCat] || []).find((x) => x.id === ds.id);
      if (state.pickTarget === "A") state.compareA = p; else state.compareB = p;
      state.sheet = null; render(); return;
    }
    if (act === "do-compare") {
      if (!state.compareA || !state.compareB) return toast("请选择两只产品");
      if (state.compareA.id === state.compareB.id) return toast("请选择两只不同的产品");
      withQuery(() => {
        const a = state.compareA, b = state.compareB;
        if (a.type === "wm") addCard("wmcmp", { a, b });
        else if (a.type === "fund") addCard("fundcmp", { a, b });
        else addCard("inscmp", { a, b });
      });
    }
  }

  function bind() {
    document.addEventListener("click", onClick);
    $("#composer").addEventListener("submit", (e) => { e.preventDefault(); handleSend($("#input").value); });
    $("#input").addEventListener("input", () => {
      const on = !!$("#input").value.trim();
      $("#sendBtn").disabled = !on;
      $("#sendBtn").classList.toggle("on", on);
    });
    $("#input").addEventListener("focus", () => $("#suggest").classList.add("show"));
    document.addEventListener("input", (e) => {
      if (e.target.id === "gname") state.saveForm.name = e.target.value;
      if (e.target.id === "gend") state.saveForm.end = e.target.value;
    });
  }

  function seedHistory() {
    HXZ.HISTORY_SEED.forEach((h) => {
      state.sessions.push({ id: h.id, title: h.title, time: h.time, preview: h.preview, messages: [{ id: uid(), kind: "home" }, { id: uid(), kind: "user", text: h.title }, { id: uid(), kind: "ai", text: "（历史会话摘要）" + h.preview }], hasInteracted: true });
    });
  }

  seedHistory();
  newSession();
  bind();
  render();
})();
