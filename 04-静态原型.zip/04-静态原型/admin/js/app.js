(function () {
  const D = window.ADMIN_DATA;
  const state = {
    page: location.hash.replace("#/", "") || "dashboard",
    userId: "ADM001",
    logged: true,
    promptKey: "prompts/opening_script",
    agentRole: "content_gen",
    orgId: "HF01",
    auditTab: "admin",
    knowTab: "rules",
    sandboxOut: "",
    dirtyRoutes: false
  };

  const $ = (id) => document.getElementById(id);
  const user = () => D.users.find((u) => u.id === state.userId);
  const canWrite = () => user().role !== "审计员";
  const isAuditor = () => user().role === "审计员";

  function toast(msg) {
    const el = $("toast");
    el.hidden = false;
    el.textContent = msg;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { el.hidden = true; }, 2200);
  }

  function closeModal() { $("modal").hidden = true; $("modal").innerHTML = ""; }
  function closeDrawer() { $("drawer").hidden = true; $("drawer").innerHTML = ""; }

  function modal(title, body, buttons) {
    $("modal").hidden = false;
    $("modal").innerHTML = `<div class="dialog">
      <h3>${title}</h3>
      <div class="body">${body}</div>
      <div class="foot">${buttons}</div>
    </div>`;
  }

  function icon(name) {
    const map = {
      dash: "M3 10h18M3 6h18M3 14h18M3 18h18",
      model: "M4 7h16v10H4zM8 7v10M16 7v10M4 12h16",
      key: "M8 12a4 4 0 1 0 3.5 2H22v-2h-2v-2h-2V8h-2.5A4 4 0 0 0 8 12z",
      route: "M4 6h10l6 6-6 6H4l6-6z",
      lab: "M9 3h6M10 3v6L5 20h14L14 9V3",
      bot: "M8 10h8M9 14h6M5 8h14v10H5zM12 8V5",
      prompt: "M5 5h14v14H5zM8 9h8M8 12h8M8 15h5",
      book: "M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 0-3 3V4z",
      box: "M3 7l9-4 9 4-9 4-9-4zm0 0v10l9 4 9-4V7",
      rec: "M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z",
      list: "M6 7h12M6 12h12M6 17h8",
      job: "M12 6v6l4 2M12 22a10 10 0 1 1 0-20 10 10 0 0 1 0 20z",
      eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
      cost: "M4 18V6m0 12h16M8 14V9m4 5V7m4 7v-3",
      audit: "M7 4h10v16H7zM10 8h4M10 12h4M10 16h2",
      org: "M8 20v-6h8v6M4 10h16L12 4z",
      gear: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm8 4h-2M6 12H4m11.5-6.5-1.4 1.4M8 16.9 6.5 18.3"
    };
    return `<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="${map[name] || map.dash}"/></svg>`;
  }

  const ICONS = { dashboard: "dash", models: "model", vault: "key", routes: "route", sandbox: "lab", agents: "bot", prompts: "prompt", knowledge: "book", products: "box", recommend: "rec", tasks: "list", jobs: "job", monitor: "eye", cost: "cost", audit: "audit", org: "org", settings: "gear" };

  function renderRail() {
    $("rail").innerHTML = `
      <div class="brand">
        <div class="brand-mark">易</div>
        <div><strong>易小助运营台</strong><em>控制面 · P0 原型</em></div>
      </div>
      ${NAV.map((g) => `
        <div class="nav-group">
          <div class="nav-label">${g.group}</div>
          ${g.items.map((it) => `
            <button class="nav-item ${state.page === it.id ? "active" : ""}" data-go="${it.id}">
              ${icon(ICONS[it.id])}<span>${it.name}</span>
            </button>`).join("")}
        </div>`).join("")}
      <div class="rail-foot">前台能力冻结。后台只治理模型、规则与观测。<br/>1440 × 900 · 请用 PC 评审</div>`;
  }

  function renderTop() {
    const u = user();
    const titles = {
      dashboard: ["运营工作台", "今天能不能用、哪里在烧钱、哪条任务挂了"],
      models: ["模型目录", "连接实例，而不是写死在代码里"],
      vault: ["凭证保险柜", "只显示掩码，轮换写入审计"],
      routes: ["场景路由", "每个前台 AI 场景可单独指定主模型与降级链"],
      sandbox: ["模型沙箱", "探测成功再启用，不污染客户会话"],
      agents: ["智能体", "启停、限流、超时；必开智能体不能同时关掉"],
      prompts: ["提示词", "版本发布，已发布不可原地改"],
      knowledge: ["知识库与合规", "规则可启停、可检索测试"],
      products: ["产品与明星", "同步主数据，只标记明星与开放期"],
      recommend: ["推荐与风测", "默认值与前台 PRD 一致"],
      tasks: ["待办与商机", "阈值改动 T+1 生效，不回刷已处理"],
      jobs: ["定时任务", "中文调度，可立即执行"],
      monitor: ["运行监测", "必须能看到场景码、是否降级、会话 ID"],
      cost: ["费用与配额", "Token、估算金额、日预算"],
      audit: ["审计与安全", "客户访问 + 管理变更"],
      org: ["组织与用户", "去掉演示下拉切换经理"],
      settings: ["系统配置", "非密钥项热更新，密钥只进保险柜"]
    };
    const [t] = titles[state.page] || ["", ""];
    $("topbar").innerHTML = `
      <div class="crumb">易小助运营台 / <b>${t}</b></div>
      <div class="top-right">
        <div class="clock" id="clock">${D.now}</div>
        <select class="role-switch" id="roleSwitch">
          ${D.users.map((x) => `<option value="${x.id}" ${x.id === state.userId ? "selected" : ""}>${x.name} · ${x.role}</option>`).join("")}
        </select>
        <div class="who"><div class="avatar">${u.short}</div>${u.name}</div>
      </div>`;
    $("ticker").innerHTML = D.health.map((h) => `
      <div class="tick"><i class="lamp ${h.s}"></i>${h.k} <b>${h.v}</b></div>`).join("");
  }

  function tagStatus(s) {
    if (s === "enabled" || s === "running" || s === "success" || s === "published" || s === "启用") return `<span class="tag ok">${({ enabled: "已启用", running: "运行中", success: "成功", published: "已发布", 启用: "启用" })[s] || s}</span>`;
    if (s === "paused" || s === "warn" || s === "gray" || s === "draft") return `<span class="tag warn">${({ paused: "已暂停", gray: "灰度", draft: "草稿" })[s] || s}</span>`;
    if (s === "fail" || s === "bad") return `<span class="tag bad">失败</span>`;
    return `<span class="tag">${s}</span>`;
  }

  function pageDashboard() {
    const top = D.agents.slice().sort((a, b) => b.calls - a.calls);
    const max = Math.max(...top.map((a) => a.calls), 1);
    return `
      <div class="page-head">
        <div><h1>运营工作台</h1><p>打开 10 秒内判断系统是否可用。主模型不可达时，健康条先红。</p></div>
        <div class="actions">
          <button class="btn" data-go="monitor">查看监测</button>
          <button class="btn primary" data-go="routes">场景路由</button>
        </div>
      </div>
      <div class="metrics">
        ${D.metrics.map((m) => `<div class="metric"><div class="k">${m.k}</div><div class="v ${m.tone || ""}">${m.v}</div><div class="s">${m.s}</div></div>`).join("")}
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="card-h">智能体运行<span>今日</span></div>
          <table class="table">
            <thead><tr><th>智能体</th><th>状态</th><th>调用</th><th>耗时</th><th>模型</th></tr></thead>
            <tbody>
              ${D.agents.map((a) => `<tr class="clickable" data-go="agents" data-role="${a.role}">
                <td>${a.name}<div class="muted" style="font-size:11px">${a.role}</div></td>
                <td>${tagStatus(a.status)}</td>
                <td class="num">${a.calls}</td>
                <td class="num">${a.ms ? (a.ms > 1000 ? (a.ms / 1000).toFixed(1) + "s" : a.ms + "ms") : "—"}</td>
                <td>${a.model}</td>
              </tr>`).join("")}
            </tbody>
          </table>
        </div>
        <div class="stack">
          <div class="card">
            <div class="card-h">Token 消耗 Top<span>今日</span></div>
            <div class="card-b">
              ${top.map((a) => `<div style="margin:10px 0">
                <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px"><span>${a.name}</span><b class="num">${a.calls}</b></div>
                <div class="bar"><i style="width:${Math.round(a.calls / max * 100)}%"></i></div>
              </div>`).join("")}
            </div>
          </div>
          <div class="card">
            <div class="card-h">日预算<span>2,267 / 30,000 tokens</span></div>
            <div class="card-b">
              <div class="bar ok"><i style="width:8%"></i></div>
              <p class="hint">达 80% 黄、100% 红。超预算只告警，不熔断展业。</p>
            </div>
          </div>
        </div>
      </div>
      <div class="grid-2b" style="margin-top:12px">
        <div class="card">
          <div class="card-h">定时任务<span>最近执行</span></div>
          <table class="table">
            <thead><tr><th>任务</th><th>结果</th><th>下次</th></tr></thead>
            <tbody>${D.jobs.slice(0, 5).map((j) => `<tr class="clickable" data-go="jobs"><td>${j.name}</td><td>${j.last}</td><td class="num">${j.next}</td></tr>`).join("")}</tbody>
          </table>
        </div>
        <div class="card">
          <div class="card-h">最近异常<span>点击进监测</span></div>
          <table class="table">
            <tbody>${D.runs.filter((r) => r.st === "fail").slice(0, 4).map((r) => `
              <tr class="clickable" data-go="monitor"><td class="num">${r.t}</td><td>${r.agent}</td><td class="warn-text">${r.err || "失败"}</td></tr>`).join("")}</tbody>
          </table>
        </div>
      </div>`;
  }

  function pageModels() {
    return `
      <div class="page-head">
        <div><h1>模型目录</h1><p>一条配置 = 提供商 + 模型名 + 端点 + 凭证。对话与嵌入必须分开。</p></div>
        <div class="actions">
          <button class="btn" data-act="probe-all" ${!canWrite() ? "disabled" : ""}>全部探测</button>
          <button class="btn primary" data-act="add-model" ${!canWrite() ? "disabled" : ""}>新增配置</button>
        </div>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>配置</th><th>提供商</th><th>用途</th><th>能力</th><th>引用</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            ${D.models.map((m) => `<tr>
              <td><b>${m.name}</b><div class="muted mono">${m.key} · ${m.model}</div></td>
              <td>${m.provider}</td>
              <td>${m.purpose}${m.def ? ` <span class="tag red">默认${m.def === "chat" ? "对话" : "嵌入"}</span>` : ""}</td>
              <td>${m.caps.map((c) => `<span class="tag">${c}</span>`).join(" ")}</td>
              <td class="num">${m.refs}</td>
              <td>${tagStatus(m.status)}</td>
              <td>
                <button class="btn" data-act="edit-model" data-key="${m.key}">编辑</button>
                ${m.status === "enabled"
                  ? `<button class="btn" data-act="disable-model" data-key="${m.key}" ${!canWrite() ? "disabled" : ""}>停用</button>`
                  : `<button class="btn primary" data-act="enable-model" data-key="${m.key}" ${!canWrite() ? "disabled" : ""}>启用</button>`}
              </td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>`;
  }

  function pageVault() {
    return `
      <div class="page-head">
        <div><h1>凭证保险柜</h1><p>接口只回掩码。参考系统那种明文 Key 回传，本期禁止。</p></div>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>配置</th><th>掩码</th><th>最近轮换</th><th>宽限期</th><th>状态</th><th></th></tr></thead>
          <tbody>${D.vault.map((v) => `<tr>
            <td class="mono">${v.key}</td><td class="mono">${v.mask}</td><td>${v.rotated}</td><td>${v.grace}</td>
            <td>${tagStatus("enabled")}</td>
            <td><button class="btn" data-act="rotate-key" data-key="${v.key}" ${!canWrite() ? "disabled" : ""}>轮换</button></td>
          </tr>`).join("")}</tbody>
        </table>
      </div>`;
  }

  function chatModels() { return D.models.filter((m) => m.purpose === "chat" && m.status === "enabled"); }

  function pageRoutes() {
    const opts = (cur) => chatModels().map((m) => `<option value="${m.key}" ${m.key === cur ? "selected" : ""}>${m.name}</option>`).join("");
    return `
      <div class="page-head">
        <div><h1>场景路由</h1><p>保存即热切换后续调用。进行中的流式对话用旧绑定跑完。</p></div>
        <div class="actions">
          <button class="btn" data-act="rollback-route" ${!canWrite() ? "disabled" : ""}>回滚上一版</button>
          <button class="btn primary" data-act="save-routes" ${!canWrite() ? "disabled" : ""}>保存并热切换</button>
        </div>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>前台场景</th><th>档位</th><th>主模型</th><th>降级 1</th><th>降级 2</th><th>启用</th></tr></thead>
          <tbody>
            ${D.routes.map((r, i) => `<tr>
              <td><b>${r.name}</b><div class="muted mono">${r.scene}</div></td>
              <td><span class="tag blue">${r.grade}</span></td>
              <td><select class="select" data-route="${i}" data-f="primary">${opts(r.primary)}</select></td>
              <td><select class="select" data-route="${i}" data-f="fb1"><option value="">—</option>${opts(r.fb1)}</select></td>
              <td><select class="select" data-route="${i}" data-f="fb2"><option value="">—</option>${opts(r.fb2)}</select></td>
              <td><button class="switch ${r.on ? "on" : ""}" role="switch" aria-checked="${r.on}" aria-label="启用 ${r.name}" data-act="toggle-route" data-i="${i}" ${!canWrite() ? "disabled" : ""}><i></i></button></td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>
      <p class="hint" style="margin-top:10px">超时 / 5xx / 429 才降级。内容安全拒答不降级，走前台 E08。</p>`;
  }

  function pageSandbox() {
    return `
      <div class="page-head">
        <div><h1>模型沙箱</h1><p>source=sandbox，不进客户会话。启用前必须探测成功，或超管写明应急原因。</p></div>
      </div>
      <div class="sandbox">
        <div class="card">
          <div class="card-h">试呼</div>
          <div class="card-b form">
            <div>
              <label class="lbl">配置</label>
              <select class="select" id="sbModel" style="width:100%">${D.models.map((m) => `<option value="${m.key}">${m.name} · ${m.purpose}</option>`).join("")}</select>
            </div>
            <div>
              <label class="lbl">Prompt</label>
              <textarea class="area" id="sbPrompt">用一句话介绍易小助。不要承诺任何收益。</textarea>
              <div class="chipset">
                <button class="chip" data-act="preset" data-t="回复 pong">健康探测</button>
                <button class="chip" data-act="preset" data-t="这个理财能保证不亏吗？">合规拒答</button>
                <button class="chip" data-act="preset" data-t="给王芳生成开场白：36岁企业主，总资产5万。">开场白</button>
              </div>
            </div>
            <button class="btn primary" data-act="run-sandbox">发送试呼</button>
          </div>
        </div>
        <div class="outbox" id="sbOut">${state.sandboxOut || "等待试呼…\n不会写入客户经理会话。"}</div>
      </div>`;
  }

  function pageAgents() {
    const a = D.agents.find((x) => x.role === state.agentRole) || D.agents[0];
    return `
      <div class="page-head"><div><h1>智能体</h1><p>前台只消费。暂停后新请求走兜底，进行中的流式不受影响。</p></div></div>
      <div class="split">
        <div class="list">${D.agents.map((x) => `
          <button class="${x.role === a.role ? "active" : ""}" data-act="pick-agent" data-role="${x.role}">
            ${x.name} ${x.must ? '<span class="tag red">必开</span>' : ""}
            <small>${x.role} · 今日 ${x.calls} 次</small>
          </button>`).join("")}</div>
        <div class="card">
          <div class="card-h">${a.name}<span>${tagStatus(a.status)}</span></div>
          <div class="card-b">
            <p style="margin-bottom:12px;color:var(--sub);font-size:13px">${a.desc}</p>
            <div class="kv">
              <dt>模型</dt><dd>${a.model}</dd>
              <dt>限流</dt><dd class="num">${a.rate} 次 / 分钟</dd>
              <dt>超时</dt><dd class="num">${a.timeout} 秒</dd>
              <dt>触发</dt><dd>${a.triggers.join(" / ")}</dd>
              <dt>技能</dt><dd class="mono">${a.skills.join(", ")}</dd>
            </div>
            <div class="actions" style="margin-top:16px">
              ${a.status === "running"
                ? `<button class="btn danger" data-act="pause-agent" data-role="${a.role}" ${!canWrite() ? "disabled" : ""}>暂停</button>`
                : `<button class="btn primary" data-act="resume-agent" data-role="${a.role}" ${!canWrite() ? "disabled" : ""}>恢复</button>`}
              <button class="btn" data-go="monitor">查看运行</button>
            </div>
          </div>
        </div>
      </div>`;
  }

  function pagePrompts() {
    const p = D.prompts.find((x) => x.key === state.promptKey) || D.prompts[0];
    return `
      <div class="page-head">
        <div><h1>提示词</h1><p>已发布版本不可原地修改。话术类不得清空合规句。</p></div>
        <div class="actions">
          <button class="btn" ${!canWrite() ? "disabled" : ""} data-act="save-draft">另存新版本</button>
          <button class="btn primary" ${!canWrite() ? "disabled" : ""} data-act="publish-prompt">发布</button>
        </div>
      </div>
      <div class="split">
        <div class="list">${D.prompts.map((x) => `
          <button class="${x.key === p.key ? "active" : ""}" data-act="pick-prompt" data-key="${x.key}">
            ${x.name} ${tagStatus(x.status)}
            <small>${x.key} · v${x.ver}${x.status === "gray" ? " · 灰度 " + x.gray + "%" : ""}</small>
          </button>`).join("")}</div>
        <div class="card">
          <div class="card-h">${p.name}<span>${p.scene}</span></div>
          <div class="card-b">
            <textarea class="area" id="promptBody" style="min-height:280px">${D.promptBody}</textarea>
            <p class="hint">变量示例：{{customer.name}} {{customer.tier}} {{customer.aum}}</p>
          </div>
        </div>
      </div>`;
  }

  function pageKnowledge() {
    return `
      <div class="page-head">
        <div><h1>知识库与合规</h1><p>P0 先把监管规则做成可运营资产。文档库可后置，但规则必须能测。</p></div>
        <div class="actions"><button class="btn" data-act="reindex" ${!canWrite() ? "disabled" : ""}>重建索引</button></div>
      </div>
      <div class="tabs">
        <button class="tab ${state.knowTab === "rules" ? "on" : ""}" data-act="know-tab" data-tab="rules">合规规则</button>
        <button class="tab ${state.knowTab === "docs" ? "on" : ""}" data-act="know-tab" data-tab="docs">知识文档</button>
      </div>
      ${state.knowTab === "rules" ? `
        <div class="grid-2">
          <div class="card">
            <table class="table">
              <thead><tr><th>编号</th><th>场景</th><th>规则</th><th></th></tr></thead>
              <tbody>${D.rules.map((r, i) => `<tr>
                <td class="mono">${r.id}</td><td>${r.scene}</td><td>${r.text}</td>
                <td><button class="switch ${r.on ? "on" : ""}" role="switch" aria-checked="${r.on}" aria-label="启用规则 ${r.id}" data-act="toggle-rule" data-i="${i}"><i></i></button></td>
              </tr>`).join("")}</tbody>
            </table>
          </div>
          <div class="card">
            <div class="card-h">检索测试</div>
            <div class="card-b form">
              <input class="field" id="ruleQ" value="这个理财能保证不亏吗？" style="width:100%" />
              <button class="btn primary" data-act="test-rule">测试命中</button>
              <div id="ruleHit" class="hint">输入客户经理可能问的话，看会不会被拦截。</div>
            </div>
          </div>
        </div>` : `
        <div class="card"><table class="table">
          <thead><tr><th>文档</th><th>分类</th><th>分块</th><th>状态</th></tr></thead>
          <tbody>${D.knowledge.map((k) => `<tr><td>${k.name}</td><td>${k.cat}</td><td class="num">${k.chunks}</td><td>${tagStatus("enabled")}</td></tr>`).join("")}</tbody>
        </table></div>`}`;
  }

  function pageProducts() {
    const stars = D.products.filter((p) => p.star && p.type === "理财").length;
    return `
      <div class="page-head">
        <div><h1>产品与明星</h1><p>禁止在运营台改收益率。明星理财最多 10 只，前台 Tab 仍先展示 3 只。</p></div>
        <div class="actions"><span class="tag red">已标记明星理财 ${stars} / 10</span></div>
      </div>
      <div class="card"><table class="table">
        <thead><tr><th>产品</th><th>代码</th><th>类型</th><th>风险</th><th>开放期</th><th>明星</th></tr></thead>
        <tbody>${D.products.map((p, i) => `<tr>
          <td>${p.name}</td><td class="mono">${p.code}</td><td>${p.type}</td><td>${p.risk}</td>
          <td>${p.open ? tagStatus("enabled") : tagStatus("paused")}</td>
          <td><button class="switch ${p.star ? "on" : ""}" role="switch" aria-checked="${p.star}" aria-label="明星 ${p.name}" data-act="toggle-star" data-i="${i}"><i></i></button></td>
        </tr>`).join("")}</tbody>
      </table></div>`;
  }

  function pageRecommend() {
    return `
      <div class="page-head"><div><h1>推荐与风测</h1><p>默认全开，与前台第 7.4 节一致。关闭风测过滤记高风险审计。</p></div></div>
      <div class="card"><div class="card-b">
        ${D.recRules.map((r, i) => `<div class="rule">
          <div><h4>${r.k}</h4><p>${r.d}</p></div>
          <button class="switch ${r.on ? "on" : ""}" role="switch" aria-checked="${r.on}" aria-label="${r.k}" data-act="toggle-rec" data-i="${i}"><i></i></button>
        </div>`).join("")}
      </div></div>`;
  }

  function pageTasks() {
    return `
      <div class="page-head"><div><h1>待办与商机</h1><p>完成率分母不含联络超期。AI 商机挖掘默认关。</p></div>
        <div class="actions"><button class="btn primary" data-act="save-task-rules" ${!canWrite() ? "disabled" : ""}>保存规则</button></div>
      </div>
      <div class="grid-2b">
        <div class="card"><div class="card-h">6 类待办开关</div><div class="card-b">
          ${D.todoTypes.map((t, i) => `<div class="rule"><h4>${t.k}</h4><button class="switch ${t.on ? "on" : ""}" role="switch" aria-checked="${t.on}" aria-label="${t.k}" data-act="toggle-todo" data-i="${i}"><i></i></button></div>`).join("")}
        </div></div>
        <div class="card"><div class="card-h">阈值</div><div class="card-b form">
          ${D.taskRules.map((t) => `<div><label class="lbl">${t.k}</label>
            <div style="display:flex;gap:8px;align-items:center"><input class="field" value="${t.v}" style="width:140px" /><span class="muted">${t.unit}</span></div>
          </div>`).join("")}
          <div class="rule"><div><h4>AI 商机挖掘</h4><p>不影响规则商机名单</p></div><button class="switch" role="switch" aria-checked="false" aria-label="AI 商机挖掘" data-act="noop"><i></i></button></div>
        </div></div>
      </div>`;
  }

  function pageJobs() {
    return `
      <div class="page-head"><div><h1>定时任务</h1><p>同一任务执行中不可重复触发。失败自动重试 3 次。</p></div></div>
      <div class="card"><table class="table">
        <thead><tr><th>任务</th><th>调度</th><th>状态</th><th>最近执行</th><th>下次</th><th></th></tr></thead>
        <tbody>${D.jobs.map((j) => `<tr>
          <td>${j.name}<div class="muted mono">${j.id}</div></td>
          <td>${j.cron}</td><td>${tagStatus(j.st)}</td><td>${j.last}</td><td class="num">${j.next}</td>
          <td>
            <button class="btn" data-act="run-job" data-id="${j.id}" ${!canWrite() ? "disabled" : ""}>立即执行</button>
          </td>
        </tr>`).join("")}</tbody>
      </table></div>`;
  }

  function pageMonitor() {
    return `
      <div class="page-head">
        <div><h1>运行监测</h1><p>禁止绕过 Harness 调模型。输出中的手机号按 C2 脱敏。</p></div>
        <div class="actions"><button class="btn">导出 Excel</button></div>
      </div>
      <div class="filters">
        <select class="select"><option>全部智能体</option>${D.agents.map((a) => `<option>${a.name}</option>`).join("")}</select>
        <select class="select"><option>全部状态</option><option>成功</option><option>失败</option></select>
        <input class="search" placeholder="会话 ID / 工号 / 场景码" />
      </div>
      <div class="card"><table class="table">
        <thead><tr><th>时间</th><th>智能体</th><th>场景</th><th>经理</th><th>状态</th><th>耗时</th><th>模型</th><th>Tokens</th></tr></thead>
        <tbody>${D.runs.map((r, i) => `<tr class="clickable" data-act="open-run" data-i="${i}">
          <td class="num">${r.t}</td><td>${r.agent}</td><td class="mono">${r.scene}</td><td>${r.rm}</td>
          <td>${tagStatus(r.st)}</td><td class="num">${r.ms}ms</td>
          <td>${r.model}${r.fb ? ' <span class="tag warn">降级</span>' : ""}</td>
          <td class="num">${r.tok}</td>
        </tr>`).join("")}</tbody>
      </table></div>`;
  }

  function pageCost() {
    const max = Math.max(...D.costTrend);
    const w = 640, h = 120, p = 8;
    const pts = D.costTrend.map((v, i) => {
      const x = p + i * ((w - p * 2) / (D.costTrend.length - 1));
      const y = h - p - (v / max) * (h - p * 2);
      return `${x},${y}`;
    }).join(" ");
    return `
      <div class="page-head"><div><h1>费用与配额</h1><p>单价来自模型目录。超预算只告警，避免展业中断。</p></div></div>
      <div class="metrics">
        <div class="metric"><div class="k">今日 Token</div><div class="v">2,267</div><div class="s">1 次 · 均 2,267</div></div>
        <div class="metric"><div class="k">本周</div><div class="v">58,546</div><div class="s">洞察刷新日偏高</div></div>
        <div class="metric"><div class="k">本月估算</div><div class="v">¥36.4</div><div class="s">按目录单价</div></div>
        <div class="metric"><div class="k">日预算</div><div class="v">8%</div><div class="s">30,000 tokens</div></div>
      </div>
      <div class="card">
        <div class="card-h">近 8 日 Token 趋势</div>
        <div class="card-b">
          <svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
            <polyline fill="none" stroke="#E6002D" stroke-width="2" points="${pts}" />
          </svg>
          <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted)">
            ${D.costDays.map((d) => `<span>${d}</span>`).join("")}
          </div>
        </div>
      </div>`;
  }

  function pageAudit() {
    return `
      <div class="page-head"><div><h1>审计与安全</h1><p>高频阈值保存即时生效。管理变更全量留痕。</p></div></div>
      <div class="tabs">
        <button class="tab ${state.auditTab === "admin" ? "on" : ""}" data-act="audit-tab" data-tab="admin">管理变更</button>
        <button class="tab ${state.auditTab === "cust" ? "on" : ""}" data-act="audit-tab" data-tab="cust">客户访问</button>
      </div>
      ${state.auditTab === "admin" ? `
        <div class="card"><table class="table">
          <thead><tr><th>时间</th><th>操作</th><th>操作人</th><th>详情</th></tr></thead>
          <tbody>${D.auditAdmin.map((a) => `<tr><td class="num">${a.t}</td><td>${a.act}</td><td>${a.who}</td><td>${a.detail}</td></tr>`).join("")}</tbody>
        </table></div>` : `
        <div class="card" style="margin-bottom:12px"><div class="card-b">
          <div style="display:flex;gap:16px;align-items:end">
            <div><label class="lbl">时间窗口（分钟）</label><input class="field" value="10" /></div>
            <div><label class="lbl">最大不同客户数</label><input class="field" value="50" /></div>
            <button class="btn primary" data-act="save-audit">保存并即时生效</button>
          </div>
        </div></div>
        <div class="card"><table class="table">
          <thead><tr><th>时间</th><th>操作</th><th>经理</th><th>客户</th><th>级别</th></tr></thead>
          <tbody>${D.auditCust.map((a) => `<tr><td class="num">${a.t}</td><td>${a.act}</td><td>${a.rm}</td><td>${a.cust}</td><td><span class="tag">${a.lv}</span></td></tr>`).join("")}</tbody>
        </table></div>`}`;
  }

  function pageOrg() {
    return `
      <div class="page-head"><div><h1>组织与用户</h1><p>生产环境用工号 + SSO。客户经理不登录运营台。</p></div>
        <div class="actions"><button class="btn primary" ${!canWrite() || isAuditor() ? "disabled" : ""}>新建用户</button></div>
      </div>
      <div class="grid-2">
        <div class="card"><div class="card-h">机构树</div>
          <div class="card-b tree">${D.orgs.map((o) => `
            <div class="tree-item lvl${o.lvl} ${state.orgId === o.id ? "on" : ""}" data-act="pick-org" data-id="${o.id}">${o.name}</div>`).join("")}
          </div>
        </div>
        <div class="card"><table class="table">
          <thead><tr><th>工号</th><th>姓名</th><th>机构</th><th>角色</th><th>状态</th></tr></thead>
          <tbody>${D.staff.map((s) => `<tr><td class="mono">${s.id}</td><td>${s.name}</td><td>${s.org}</td><td>${s.role}</td><td>${tagStatus(s.st)}</td></tr>`).join("")}</tbody>
        </table></div>
      </div>`;
  }

  function pageSettings() {
    return `
      <div class="page-head"><div><h1>系统配置</h1><p>密钥不准出现在本页。</p></div>
        <div class="actions"><button class="btn primary" data-act="save-settings" ${!canWrite() ? "disabled" : ""}>保存</button></div>
      </div>
      ${D.settings.map((g) => `<div class="card" style="margin-bottom:12px"><div class="card-h">${g.cat}</div><div class="card-b form-row">
        ${g.items.map((it) => `<div><label class="lbl">${it.k}</label>
          <div style="display:flex;gap:8px;align-items:center"><input class="field" value="${it.v}" /><span class="muted">${it.unit}</span></div>
        </div>`).join("")}
      </div></div>`).join("")}
      <div class="card"><div class="card-b">
        <div class="rule"><div><h4>每日资讯</h4><p>前台 P80</p></div><button class="switch on" role="switch" aria-checked="true" aria-label="每日资讯"><i></i></button></div>
        <div class="rule"><div><h4>风格切换</h4><p>口语 / 专业</p></div><button class="switch on" role="switch" aria-checked="true" aria-label="风格切换"><i></i></button></div>
        <div class="rule"><div><h4>管户隔离</h4><p>不可关闭</p></div><button class="switch on" role="switch" aria-checked="true" aria-label="管户隔离" disabled><i></i></button></div>
      </div></div>`;
  }

  const pages = {
    dashboard: pageDashboard, models: pageModels, vault: pageVault, routes: pageRoutes,
    sandbox: pageSandbox, agents: pageAgents, prompts: pagePrompts, knowledge: pageKnowledge,
    products: pageProducts, recommend: pageRecommend, tasks: pageTasks, jobs: pageJobs,
    monitor: pageMonitor, cost: pageCost, audit: pageAudit, org: pageOrg, settings: pageSettings
  };

  function renderLogin() {
    $("app").hidden = true;
    $("login").hidden = false;
    $("login").innerHTML = `<div class="login-card">
      <div class="brand-mark" style="width:36px;height:36px;line-height:36px;font-size:16px">易</div>
      <h1>易小助运营台</h1>
      <p>行内 SSO。演示可用工号直接进入。</p>
      <input class="field" value="ADM001" readonly />
      <input class="field" type="password" value="********" readonly />
      <button class="btn primary" id="doLogin">使用周衡（超管）进入</button>
    </div>`;
  }

  function render() {
    if (!state.logged) return renderLogin();
    $("login").hidden = true;
    $("app").hidden = false;
    renderRail();
    renderTop();
    $("main").innerHTML = (pages[state.page] || pageDashboard)();
    location.hash = "#/" + state.page;
  }

  function go(page) {
    state.page = page;
    closeDrawer();
    closeModal();
    render();
    $("main").scrollTop = 0;
  }

  function openRun(i) {
    const r = D.runs[i];
    $("drawer").hidden = false;
    $("drawer").innerHTML = `
      <div class="drawer-h">运行详情 <button class="btn" data-act="close-drawer">关闭</button></div>
      <div class="drawer-b">
        <div class="kv">
          <dt>时间</dt><dd>${r.t}</dd>
          <dt>智能体</dt><dd>${r.agent} / ${r.method}</dd>
          <dt>场景</dt><dd class="mono">${r.scene}</dd>
          <dt>会话</dt><dd class="mono">${r.sid}</dd>
          <dt>经理</dt><dd>${r.rm}</dd>
          <dt>模型</dt><dd>${r.model}${r.fb ? "（降级）" : ""}</dd>
          <dt>耗时</dt><dd class="num">${r.ms} ms</dd>
          <dt>Tokens</dt><dd class="num">${r.tok}</dd>
          <dt>状态</dt><dd>${tagStatus(r.st)}</dd>
        </div>
        ${r.err ? `<p class="warn-text" style="margin-top:14px">${r.err}</p>` : ""}
        <p class="hint" style="margin-top:16px">输入摘要已脱敏。完整 JSON 需导出审批后下载。</p>
      </div>`;
  }

  function handle(e) {
    const t = e.target.closest("[data-go],[data-act],#doLogin");
    if (!t) return;

    if (t.id === "doLogin") { state.logged = true; render(); return; }
    if (t.dataset.go) {
      if (t.dataset.role) state.agentRole = t.dataset.role;
      go(t.dataset.go);
      return;
    }

    const act = t.dataset.act;
    if (act === "close-drawer") return closeDrawer();
    if (act === "pick-agent") { state.agentRole = t.dataset.role; render(); return; }
    if (act === "pick-prompt") { state.promptKey = t.dataset.key; render(); return; }
    if (act === "know-tab") { state.knowTab = t.dataset.tab; render(); return; }
    if (act === "audit-tab") { state.auditTab = t.dataset.tab; render(); return; }
    if (act === "pick-org") { state.orgId = t.dataset.id; render(); return; }

    if (act === "toggle-route") {
      D.routes[+t.dataset.i].on = !D.routes[+t.dataset.i].on;
      state.dirtyRoutes = true; render(); return;
    }
    if (act === "toggle-star") {
      const p = D.products[+t.dataset.i];
      if (!p.star && D.products.filter((x) => x.star && x.type === "理财").length >= 10) return toast("明星理财最多 10 只");
      p.star = !p.star; render(); return;
    }
    if (act === "toggle-rec") {
      const r = D.recRules[+t.dataset.i];
      if (r.k === "未风测隐藏理财基金" && r.on) {
        return modal("高风险操作", "关闭风测过滤将允许未测评客户看到理财/基金推荐。需超管确认，并写入审计。",
          `<button class="btn" id="mCancel">取消</button><button class="btn danger" id="mOk">仍然关闭</button>`);
      }
      r.on = !r.on; render(); return;
    }
    if (act === "toggle-todo") { D.todoTypes[+t.dataset.i].on = !D.todoTypes[+t.dataset.i].on; render(); return; }
    if (act === "toggle-rule") { D.rules[+t.dataset.i].on = !D.rules[+t.dataset.i].on; render(); return; }

    if (act === "save-routes") {
      return modal("确认热切换", "此操作会热切换后续调用，进行中的对话不受影响。新的开场白、对比总结将使用你刚选的主模型。",
        `<button class="btn" id="mCancel">取消</button><button class="btn primary" id="mHot">确认切换</button>`);
    }
    if (act === "rollback-route") {
      D.routes[1].primary = "deepseek-flash";
      toast("已回滚 scene.portrait_script 到上一版本");
      render(); return;
    }
    if (act === "enable-model") {
      const m = D.models.find((x) => x.key === t.dataset.key);
      return modal("确认启用 " + m.name, "启用前应沙箱探测成功。应急可跳过探测，但必须填写原因。",
        `<label class="lbl"><input type="checkbox" id="skipProbe" /> 跳过探测（应急）</label>
         <div class="foot" style="padding:12px 0 0">
           <button class="btn" id="mCancel">取消</button>
           <button class="btn" data-go="sandbox">去沙箱</button>
           <button class="btn primary" id="mEnable">启用</button>
         </div>`);
    }
    if (act === "disable-model") {
      const m = D.models.find((x) => x.key === t.dataset.key);
      if (m.refs > 0) return toast("仍被 " + m.refs + " 条路由引用，不能停用");
      m.status = "draft"; render(); toast("已停用 " + m.name); return;
    }
    if (act === "add-model" || act === "edit-model") {
      const m = D.models.find((x) => x.key === t.dataset.key);
      $("modal").hidden = false;
      $("modal").innerHTML = `<div class="dialog wide"><h3>${m ? "编辑模型配置" : "新增模型配置"}</h3>
        <div class="body form">
          <div class="form-row">
            <div><label class="lbl">config_key</label><input class="field" style="width:100%" value="${m ? m.key : ""}" ${m ? "readonly" : ""} /></div>
            <div><label class="lbl">显示名</label><input class="field" style="width:100%" value="${m ? m.name : ""}" /></div>
          </div>
          <div class="form-row">
            <div><label class="lbl">提供商</label><select class="select" style="width:100%"><option>deepseek</option><option>qwen</option><option>zhipu</option><option>openai_compat</option><option>internal</option></select></div>
            <div><label class="lbl">用途</label><select class="select" style="width:100%"><option>chat</option><option>embedding</option></select></div>
          </div>
          <div><label class="lbl">API Base</label><input class="field" style="width:100%" value="${m ? m.base : "https://"}" /></div>
          <div><label class="lbl">API Key</label><input class="field" type="password" style="width:100%" value="${m ? "••••已配置" : ""}" placeholder="留空表示不改" /></div>
          <p class="hint">凭证写入保险柜。编辑时占位「已配置」，页面不回显明文。</p>
        </div>
        <div class="foot"><button class="btn" id="mCancel">取消</button><button class="btn primary" id="mSaveModel">保存</button></div>
      </div>`;
      return;
    }
    if (act === "rotate-key") {
      return modal("轮换密钥 · " + t.dataset.key, "新 Key 生效后，旧 Key 进入 24 小时宽限期，可回滚。",
        `<input class="field" type="password" placeholder="新 API Key" style="width:100%;margin:8px 0" />
         <div class="foot" style="padding:8px 0 0"><button class="btn" id="mCancel">取消</button><button class="btn primary" id="mRotate">确认轮换</button></div>`);
    }
    if (act === "preset") {
      $("sbPrompt").value = t.dataset.t; return;
    }
    if (act === "run-sandbox") {
      const model = $("sbModel").value;
      const q = $("sbPrompt").value;
      const box = $("sbOut");
      box.textContent = "正在调用 " + model + " …";
      setTimeout(() => {
        let out = "";
        if (/保证|不亏|保本/.test(q)) out = "【合规拦截】不得承诺保本保收益。命中 R00022。\n不降级，按前台 E08 返回。";
        else if (/pong/i.test(q)) out = "pong\n\nlatency 312ms · tokens 4 · source=sandbox";
        else out = "易小助是给个人客户经理用的对话式展业工作台，用来在管户范围内找人、读懂客户、查产品、拿话术。\n\nlatency 1.84s · tokens 86 · source=sandbox";
        box.textContent = out;
        toast("试呼完成，已写入监测（sandbox）");
      }, 700);
      return;
    }
    if (act === "pause-agent") {
      const a = D.agents.find((x) => x.role === t.dataset.role);
      const mustOn = D.agents.filter((x) => x.must && x.status === "running" && x.role !== a.role);
      if (a.must && mustOn.length === 0) return toast("不能暂停最后一个必开智能体");
      a.status = "paused"; render(); toast(a.name + " 已暂停，新请求走前台兜底"); return;
    }
    if (act === "resume-agent") {
      const a = D.agents.find((x) => x.role === t.dataset.role);
      a.status = "running"; render(); toast(a.name + " 已恢复"); return;
    }
    if (act === "publish-prompt") {
      return modal("发布提示词", "发布后前台下一句对应场景将使用新版本。产品话术必须保留合规句。",
        `<button class="btn" id="mCancel">取消</button><button class="btn primary" id="mPublish">发布</button>`);
    }
    if (act === "save-draft") { toast("已另存为草稿 v" + "2.1.1"); return; }
    if (act === "reindex") { toast("索引重建已加入任务队列"); go("jobs"); return; }
    if (act === "test-rule") {
      $("ruleHit").innerHTML = `<b style="color:var(--brand)">命中 R00022</b> · 风险警示<br/>标准话术：过往业绩不代表未来表现，请以产品合同为准。`;
      return;
    }
    if (act === "save-task-rules") { toast("规则已保存，名单 T+1 按新阈值重算"); return; }
    if (act === "run-job") {
      return modal("立即执行", "将立即运行「" + D.jobs.find((j) => j.id === t.dataset.id).name + "」。同一任务进行中不可重复触发。",
        `<button class="btn" id="mCancel">取消</button><button class="btn primary" id="mRun">执行</button>`);
    }
    if (act === "open-run") return openRun(+t.dataset.i);
    if (act === "save-audit") { toast("阈值已更新并即时生效"); return; }
    if (act === "save-settings") { toast("配置已保存"); return; }
    if (act === "probe-all") { toast("3 条启用配置探测通过，1 条草稿已跳过"); return; }
  }

  document.addEventListener("click", (e) => {
    if (e.target.id === "modal") closeModal();
    if (e.target.id === "mCancel") { closeModal(); return; }
    if (e.target.id === "mHot") { closeModal(); state.dirtyRoutes = false; toast("路由已热切换，新请求走新模型"); D.auditAdmin.unshift({ t: "10:28:01", act: "热切换路由", who: user().name, detail: "场景路由已发布" }); }
    if (e.target.id === "mEnable") {
      closeModal();
      toast("已启用。建议再到沙箱做一次业务句试呼");
    }
    if (e.target.id === "mSaveModel") { closeModal(); toast("已保存，凭证仅显示掩码"); }
    if (e.target.id === "mRotate") { closeModal(); toast("新密钥已生效，旧密钥宽限 24 小时"); }
    if (e.target.id === "mPublish") { closeModal(); toast("已发布，前台下一句生效"); }
    if (e.target.id === "mRun") { closeModal(); toast("任务已开始，完成后写入监测"); }
    if (e.target.id === "mOk") {
      closeModal();
      const r = D.recRules.find((x) => x.k === "未风测隐藏理财基金");
      if (r) r.on = false;
      render();
      toast("已关闭风测过滤，已记高风险审计");
    }
    handle(e);
  });
  document.addEventListener("change", (e) => {
    if (e.target.id === "roleSwitch") {
      state.userId = e.target.value;
      render();
      toast("已切换为 " + user().name + " · " + user().role);
      return;
    }
    const sel = e.target.closest("select[data-route]");
    if (sel) {
      D.routes[+sel.dataset.route][sel.dataset.f] = sel.value;
      state.dirtyRoutes = true;
    }
  });
  window.addEventListener("hashchange", () => {
    const p = location.hash.replace("#/", "");
    if (p && p !== state.page && pages[p]) go(p);
  });

  render();
})();
