window.ADMIN_DATA = {
  now: "2026-08-25 10:27:18",
  users: [
    { id: "ADM001", name: "周衡", role: "超管", short: "周" },
    { id: "ML001", name: "沈岚", role: "模型管理员", short: "沈" },
    { id: "OP001", name: "吴倩", role: "运营配置", short: "吴" },
    { id: "KB001", name: "郑起", role: "知识管理", short: "郑" },
    { id: "AU001", name: "马肃", role: "审计员", short: "马" }
  ],
  health: [
    { k: "AI 网关", v: "正常", s: "ok" },
    { k: "主模型", v: "deepseek-flash", s: "ok" },
    { k: "嵌入模型", v: "dashscope-emb", s: "ok" },
    { k: "知识库索引", v: "3 天前重建", s: "warn" },
    { k: "资讯任务", v: "08:35 成功", s: "ok" }
  ],
  metrics: [
    { k: "智能体", v: "6", s: "运行中 5 · 已暂停 1" },
    { k: "今日调用", v: "1,284", s: "较昨日 +12%" },
    { k: "今日异常", v: "5", s: "作战包历史残留 0 · 内容生成 2", tone: "warn" },
    { k: "今日 Token", v: "2,267", s: "估算 ¥0.18 · 预算 8%" }
  ],
  models: [
    { key: "deepseek-flash", name: "DeepSeek Flash", provider: "deepseek", model: "deepseek-v4-flash", base: "https://api.deepseek.com/v1", purpose: "chat", ctx: "128K", priceIn: 0.14, priceOut: 0.28, status: "enabled", refs: 8, caps: ["流式", "工具调用", "国内合规"], def: "chat", updated: "08-24 18:12", by: "沈岚" },
    { key: "qwen-max", name: "通义千问 Max", provider: "qwen", model: "qwen-max", base: "https://dashscope.aliyuncs.com/compatible-mode/v1", purpose: "chat", ctx: "32K", priceIn: 0.40, priceOut: 1.20, status: "enabled", refs: 7, caps: ["流式", "长上下文"], def: "", updated: "08-20 09:40", by: "周衡" },
    { key: "dashscope-emb", name: "百炼 Embedding", provider: "qwen", model: "text-embedding-v3", base: "https://dashscope.aliyuncs.com/compatible-mode/v1", purpose: "embedding", ctx: "8K", priceIn: 0.07, priceOut: 0, status: "enabled", refs: 1, caps: ["1024 维"], def: "embedding", updated: "07-31 00:29", by: "沈岚" },
    { key: "internal-guard", name: "行内合规小模型", provider: "internal", model: "guard-7b", base: "https://llm.intra.bank/v1", purpose: "chat", ctx: "8K", priceIn: 0, priceOut: 0, status: "draft", refs: 0, caps: ["内容安全"], def: "", updated: "08-18 11:02", by: "沈岚" }
  ],
  vault: [
    { key: "deepseek-flash", mask: "sk-••••9169", rotated: "07-31 00:29", grace: "—", status: "生效中" },
    { key: "qwen-max", mask: "sk-••••Yxs", rotated: "07-30 22:57", grace: "—", status: "生效中" },
    { key: "dashscope-emb", mask: "sk-••••Yxs", rotated: "07-30 22:57", grace: "—", status: "生效中" }
  ],
  routes: [
    { scene: "scene.router", name: "意图识别", agent: "RouterAgent", grade: "轻量", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "沈岚" },
    { scene: "scene.portrait_script", name: "开场白话术", agent: "ContentAgent", grade: "标准", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "沈岚" },
    { scene: "scene.product_script", name: "产品 / 权益话术", agent: "ContentAgent", grade: "标准", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "吴倩" },
    { scene: "scene.script_style", name: "口语 / 专业切换", agent: "ContentAgent", grade: "轻量", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "吴倩" },
    { scene: "scene.product_compare", name: "产品对比总结", agent: "QAAgent", grade: "标准", primary: "qwen-max", fb1: "deepseek-flash", fb2: "", on: true, by: "沈岚" },
    { scene: "scene.recommend_reason", name: "推荐理由", agent: "RecommendAgent", grade: "标准", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "吴倩" },
    { scene: "scene.daily_review", name: "昨日工作总结", agent: "ContentAgent", grade: "轻量", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "周衡" },
    { scene: "scene.daily_digest", name: "每日资讯", agent: "ContentAgent", grade: "轻量", primary: "deepseek-flash", fb1: "qwen-max", fb2: "", on: true, by: "周衡" },
    { scene: "scene.qa_rag", name: "自由问答 / 产品解读", agent: "QAAgent", grade: "标准+RAG", primary: "qwen-max", fb1: "deepseek-flash", fb2: "", on: true, by: "郑起" },
    { scene: "scene.opp_mining", name: "AI 商机挖掘", agent: "OppMiningAgent", grade: "强推理", primary: "qwen-max", fb1: "deepseek-flash", fb2: "", on: false, by: "周衡" },
    { scene: "scene.insight_batch", name: "客户洞察批量", agent: "CustomerInsightAgent", grade: "标准", primary: "qwen-max", fb1: "deepseek-flash", fb2: "", on: true, by: "沈岚" }
  ],
  agents: [
    { role: "router", name: "对话路由", must: true, status: "running", calls: 412, err: 0, ms: 180, model: "跟随路由", skills: ["classify_intent", "route_to_expert", "fallback"], triggers: ["on_demand"], rate: 120, timeout: 8, desc: "意图识别与兜底，不替代静态查询。" },
    { role: "qa_assistant", name: "智能问答", must: true, status: "running", calls: 96, err: 1, ms: 2100, model: "跟随路由", skills: ["ask", "search_products", "explain_product"], triggers: ["on_demand"], rate: 40, timeout: 30, desc: "产品解读、自由问、对比总结，走 RAG。" },
    { role: "content_gen", name: "内容生成", must: true, status: "running", calls: 74, err: 2, ms: 2629, model: "跟随路由", skills: ["gen_review", "gen_digest", "opening_script", "product_script"], triggers: ["scheduled", "on_demand"], rate: 30, timeout: 300, desc: "话术、昨日总结、资讯摘要。" },
    { role: "recommend", name: "推荐", must: true, status: "running", calls: 188, err: 0, ms: 420, model: "跟随路由", skills: ["rank_candidates", "gen_reasons"], triggers: ["on_demand"], rate: 60, timeout: 15, desc: "理财 / 基金 / 存款 / 权益 / 活动策略执行。" },
    { role: "customer_insight", name: "客户洞察", must: false, status: "running", calls: 7, err: 0, ms: 18740, model: "跟随路由", skills: ["query_profile", "analyze_behavior", "detect_risk"], triggers: ["scheduled", "on_demand"], rate: 10, timeout: 600, desc: "画像解读增强与批量洞察快照。" },
    { role: "opportunity_miner", name: "商机挖掘", must: false, status: "paused", calls: 0, err: 0, ms: 0, model: "跟随路由", skills: ["scan_portfolio", "detect_signals"], triggers: ["on_demand"], rate: 8, timeout: 600, desc: "默认关闭。前台商机以规则名单为主。" }
  ],
  prompts: [
    { key: "prompts/router", name: "路由分类", scene: "scene.router", ver: "1.4.0", status: "published", gray: 0, by: "沈岚", updated: "08-22" },
    { key: "prompts/opening_script", name: "开场白话术", scene: "scene.portrait_script", ver: "2.1.0", status: "published", gray: 0, by: "吴倩", updated: "08-24" },
    { key: "prompts/product_script", name: "产品话术", scene: "scene.product_script", ver: "2.0.1", status: "published", gray: 0, by: "吴倩", updated: "08-21" },
    { key: "prompts/style_switch", name: "风格切换", scene: "scene.script_style", ver: "1.1.0", status: "published", gray: 0, by: "吴倩", updated: "08-12" },
    { key: "prompts/compare_summary", name: "对比总结", scene: "scene.product_compare", ver: "1.3.2", status: "gray", gray: 20, by: "沈岚", updated: "08-25" },
    { key: "prompts/daily_review", name: "昨日总结", scene: "scene.daily_review", ver: "1.2.0", status: "published", gray: 0, by: "周衡", updated: "08-19" },
    { key: "prompts/daily_digest", name: "资讯摘要", scene: "scene.daily_digest", ver: "1.0.3", status: "published", gray: 0, by: "周衡", updated: "08-25" },
    { key: "prompts/qa_rag", name: "RAG 问答", scene: "scene.qa_rag", ver: "1.6.0", status: "published", gray: 0, by: "郑起", updated: "08-16" },
    { key: "prompts/safety_refuse", name: "安全拒答", scene: "scene.router", ver: "1.0.0", status: "published", gray: 0, by: "马肃", updated: "07-30" }
  ],
  promptBody: `你是易小助，服务个人客户经理。根据客户画像生成开场白。

结构：称呼 + 经理身份 + 1 个真实行为点 + 1 个价值点 + 低压力预约。
约束：
- 必须映射已提供的客户事实，禁止虚构收益承诺
- 默认口语化
- 不贬低他行，不保证审批

客户：{{customer.name}} / {{customer.tier}} / 总资产 {{customer.aum}}
最近行为：{{customer.recent_behavior}}`,
  knowledge: [
    { name: "AI对话约束规则.md", cat: "合规", chunks: 18, on: true },
    { name: "理财产品说明书-安盈稳利", cat: "产品介绍", chunks: 12, on: true },
    { name: "个人贷款管理办法-规则", cat: "政策法规", chunks: 59, on: true },
    { name: "消费者权益保护-规则", cat: "政策法规", chunks: 59, on: true }
  ],
  rules: [
    { id: "R00017", scene: "业务咨询", text: "不得引导客户规避面签要求。", on: true },
    { id: "R00022", scene: "风险警示", text: "不得承诺保本保收益。", on: true },
    { id: "R00031", scene: "合规警示", text: "不得协助简化风险评估。", on: true },
    { id: "R00044", scene: "信息咨询", text: "过往业绩不代表未来表现。", on: true }
  ],
  products: [
    { name: "「安盈」稳利1年", code: "AXLCSH20253001", type: "理财", star: true, open: true, risk: "R2" },
    { name: "苏银理财恒源1年5期", code: "SYLC2025H05", type: "理财", star: true, open: true, risk: "R3" },
    { name: "西部利得某货币 A", code: "WLHB001", type: "基金", star: false, open: true, risk: "R1" },
    { name: "阳光人寿金吉利G款", code: "YG-G", type: "保险", star: false, open: true, risk: "—" },
    { name: "普惠金融存单 1年期", code: "DP000017", type: "存款", star: false, open: true, risk: "—" }
  ],
  recRules: [
    { k: "理财到期策略", d: "同类、同期限、开放期、起购≤到期、风险≤风测，取 3", on: true },
    { k: "理财浏览兜底", d: "近 30 天浏览 Top5", on: true },
    { k: "基金浏览推荐", d: "近 30 天浏览 Top5，过风测", on: true },
    { k: "存款到期策略", d: "同小类同币种、存期≤到期", on: true },
    { k: "存款兜底产品", d: "DP000017 / 1Y", on: true },
    { k: "未风测隐藏理财基金", d: "存款仍展示", on: true },
    { k: "明星也过风测", d: "与个性化推荐同一过滤", on: true }
  ],
  taskRules: [
    { k: "联络超期天数", v: "90", unit: "天" },
    { k: "大额异动阈值", v: "50000", unit: "元" },
    { k: "代发窗口", v: "7", unit: "天" },
    { k: "流失概率标红", v: "70", unit: "%" }
  ],
  todoTypes: [
    { k: "产品到期", on: true }, { k: "资产大幅变动", on: true }, { k: "贷款逾期", on: true },
    { k: "生日提醒", on: true }, { k: "联络超期", on: true }, { k: "信用卡待办", on: true }
  ],
  orgs: [
    { id: "HQ", name: "总行零售部", lvl: 1 },
    { id: "HF", name: "合肥分行", lvl: 2 },
    { id: "HF01", name: "政务区支行", lvl: 3 },
    { id: "HF02", name: "天鹅湖支行", lvl: 3 },
    { id: "WH", name: "芜湖分行", lvl: 2 }
  ],
  staff: [
    { id: "ADM001", name: "周衡", org: "总行零售部", role: "超管", st: "启用" },
    { id: "ML001", name: "沈岚", org: "总行零售部", role: "模型管理员", st: "启用" },
    { id: "OP001", name: "吴倩", org: "合肥分行", role: "运营配置", st: "启用" },
    { id: "KB001", name: "郑起", org: "总行零售部", role: "知识管理", st: "启用" },
    { id: "AU001", name: "马肃", org: "总行内控", role: "审计员", st: "启用" },
    { id: "RM001", name: "李明", org: "政务区支行", role: "客户经理（前台）", st: "启用" }
  ],
  jobs: [
    { id: "daily_news_fetch", name: "每日资讯抓取", cron: "每日 08:30", st: "running", last: "成功 · 抓取 7 条", next: "08/26 08:30" },
    { id: "daily_digest_gen", name: "资讯摘要生成", cron: "每日 08:35", st: "running", last: "成功 · 6 条要闻", next: "08/26 08:35" },
    { id: "daily_review_gen", name: "昨日工作总结", cron: "每日 20:00", st: "running", last: "成功 · 3/3 位经理", next: "08/25 20:00" },
    { id: "weekly_insight_gen", name: "客户洞察刷新", cron: "每周日 03:00", st: "running", last: "成功 · 批量洞察", next: "08/30 03:00" },
    { id: "daily_task_materialize", name: "待办/商机名单物化", cron: "每日 06:00", st: "running", last: "成功", next: "08/26 06:00" },
    { id: "audit_daily_report", name: "审计日报", cron: "每日 08:00", st: "running", last: "昨日查询 0 次", next: "08/26 08:00" },
    { id: "data_anonymization", name: "数据匿名化", cron: "每日 03:00", st: "running", last: "0 名到期客户", next: "08/26 03:00" }
  ],
  runs: [
    { t: "08:35:03", agent: "内容生成", method: "gen_digest", scene: "scene.daily_digest", rm: "—", st: "success", ms: 3754, model: "deepseek-flash", fb: false, tok: 2267, sid: "sess_d8a1" },
    { t: "10:12:41", agent: "内容生成", method: "opening_script", scene: "scene.portrait_script", rm: "李明", st: "success", ms: 1840, model: "deepseek-flash", fb: false, tok: 612, sid: "sess_c12f" },
    { t: "10:14:08", agent: "智能问答", method: "compare_summary", scene: "scene.product_compare", rm: "李明", st: "success", ms: 2210, model: "qwen-max", fb: false, tok: 880, sid: "sess_c12f" },
    { t: "10:18:22", agent: "智能问答", method: "ask", scene: "scene.qa_rag", rm: "李明", st: "success", ms: 1980, model: "qwen-max", fb: true, tok: 1044, sid: "sess_c12f" },
    { t: "09:02:11", agent: "推荐", method: "rank_candidates", scene: "scene.recommend_reason", rm: "李明", st: "success", ms: 390, model: "deepseek-flash", fb: false, tok: 140, sid: "sess_a90c" },
    { t: "08:41:16", agent: "内容生成", method: "product_script", scene: "scene.product_script", rm: "李明", st: "fail", ms: 30012, model: "deepseek-flash", fb: true, tok: 0, sid: "sess_b33e", err: "主模型超时，已降级成功但本条记录为首次失败" }
  ],
  costTrend: [3336, 4126, 4670, 4832, 4222, 32423, 2670, 2267],
  costDays: ["08-18", "08-19", "08-20", "08-21", "08-22", "08-23", "08-24", "08-25"],
  auditCust: [
    { t: "10:14:09", act: "查看画像", rm: "李明", cust: "王芳 100017", lv: "C2", anomaly: false },
    { t: "10:12:40", act: "查询客户", rm: "李明", cust: "王*", lv: "C2", anomaly: false },
    { t: "09:40:02", act: "查看持仓", rm: "李明", cust: "王磊 100018", lv: "C3", anomaly: false }
  ],
  auditAdmin: [
    { t: "10:03:11", act: "热切换路由", who: "沈岚", detail: "scene.portrait_script 主模型 deepseek-flash" },
    { t: "09:18:44", act: "发布提示词", who: "吴倩", detail: "prompts/opening_script 2.1.0" },
    { t: "08:01:02", act: "立即执行任务", who: "周衡", detail: "daily_digest_gen" }
  ],
  settings: [
    { cat: "对话", items: [
      { k: "首 token 超时", v: "8", unit: "秒" },
      { k: "会话保留天数", v: "30", unit: "天" },
      { k: "历史条数上限", v: "50", unit: "条" }
    ]},
    { cat: "安全", items: [
      { k: "高频窗口", v: "10", unit: "分钟" },
      { k: "最大不同客户数", v: "50", unit: "个" }
    ]},
    { cat: "RAG", items: [
      { k: "topK", v: "5", unit: "" },
      { k: "分块长度", v: "1500", unit: "字" }
    ]}
  ]
};

window.NAV = [
  { group: "总览", items: [{ id: "dashboard", name: "运营工作台" }] },
  { group: "模型管理", items: [
    { id: "models", name: "模型目录" },
    { id: "vault", name: "凭证保险柜" },
    { id: "routes", name: "场景路由" },
    { id: "sandbox", name: "模型沙箱" }
  ]},
  { group: "AI 治理", items: [
    { id: "agents", name: "智能体" },
    { id: "prompts", name: "提示词" },
    { id: "knowledge", name: "知识库与合规" }
  ]},
  { group: "业务规则", items: [
    { id: "products", name: "产品与明星" },
    { id: "recommend", name: "推荐与风测" },
    { id: "tasks", name: "待办与商机" }
  ]},
  { group: "运行", items: [
    { id: "jobs", name: "定时任务" },
    { id: "monitor", name: "运行监测" },
    { id: "cost", name: "费用与配额" },
    { id: "audit", name: "审计与安全" }
  ]},
  { group: "系统", items: [
    { id: "org", name: "组织与用户" },
    { id: "settings", name: "系统配置" }
  ]}
];
