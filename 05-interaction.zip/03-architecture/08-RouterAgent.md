# RouterAgent · AI 对话路由智能体设计方案

> **版本**：v1.0 | **日期**：2026-07-31 | **状态**：📐 设计中
>
> **定位**：AgentOS 对话模式下的智能调度中枢，负责意图识别、Agent 分发、Skill 直接调用、响应合并与问答后建议生成。不是全局调度器，而是 AI 对话面板中的动态路由层。

---

## 一、设计原则

### 1.1 核心哲学

**"不是为了对话而对话，而是通过对话更好的提升效率。"**

RouterAgent 的终极目标是 **最短路径解决问题**：
- 能查数据库不调 LLM
- 能跳页面不多说一句话
- 确实需要推理才出动 Agent

### 1.2 三大原则

| 原则 | 内容 |
|------|------|
| **原则一：静态路由不可替代** | 前端明确 Agent 调用场景（点击"AI 挖掘"→`api.aiMine()`）保留现有静态 API 路由，这是最高效率方式，绝不移除 |
| **原则二：RouterAgent 边界收窄** | RouterAgent **仅在 AI 对话模式** 中承担动态路由。用户自由输入文本 → 意图识别 → 决定调用哪个(些)Agent → 合并响应。不是全局调度器，而是对话场景的智能分发器 |
| **原则三：>0.75 置信度单命中 → 跳转链接** | 意图识别命中唯一一个已有静态路由 Agent 且 confidence > 0.75 时，RouterAgent 不代为执行，而是在对话中返回前端跳转链接，用户一键跳转到对应页面完成操作 |

---

## 二、系统定位

### 2.1 在 AgentOS 中的位置

```
前端 Vue 3 SPA
  ├── 静态 API 调用 (api.aiMine / api.aiQaAsk / ...)  ← 不受 RouterAgent 影响
  │        → FastAPI 路由 → harness.invoke(agent, method) → 直接执行
  │
  └── AI 对话面板 (AiChat.vue)                          ← RouterAgent 在此生效
           │  POST /api/ai/chat { question, manager_id }
           ▼
       RouterAgent.classify_intent(question)
           │
           ├── data_query    → harness.skills.execute()
           ├── single_agent  → harness.invoke(agent_role, method)
           ├── multi_agent   → parallel invoke + merge
           ├── navigate      → return { type: "navigate", link }
           └── fallback      → RouterAgent.fallback()
```

### 2.2 与现有调用体系的关系

| 调用路径 | 是否经过 RouterAgent | 说明 |
|---------|:---:|------|
| 前端按钮 → 静态 API → Agent | ❌ 不经过 | 保持现有路径，最高效 |
| AI 对话面板 → User 自由输入 | ✅ 经过 | RouterAgent 动态路由 |
| 管理后台 → Agent 调用 | ❌ 不经过 | 后台走独立 API |
| 定时任务 → Agent 调用 | ❌ 不经过 | Scheduler 直接调度 |

---

## 三、意图分类体系

### 3.1 classify_intent() 输出结构

```python
{
    "intent_category": "data_query" | "knowledge_qa" | "action" | "complex" | "ambiguous",

    "sub_type": "product_list" | "cust_detail" | "opp_progress" | "task_count"
              | "product_explain" | "business_qa" | "allocation_advice"
              | "opp_mining" | "battle_gen" | "insight_gen" | "schedule_adj",

    "entities": [
        { "type": "customer", "value": "王建国", "resolved_id": "cust_001" },
        { "type": "product", "value": "R2理财", "resolved_id": None },
    ],

    "target": "skill:query_products" | "agent:qa_assistant" | "agent:opp_mining"
            | "agent:battle_pkg" | "agent:customer_insight" | ...,

    "agent_count": 1,                # 单 Agent / 多 Agent

    "matched_static_route": "/opportunity?cust_id=cust_001" | None,
    "route_confidence": 0.92,

    "requires_llm": False,           # 是否需要 LLM 参与
}
```

### 3.2 意图分类维度

RouterAgent 将用户意图归入以下五大类别：

#### A. data_query — 数据查询（问数）

用户问"是什么/有多少"，走结构化查询管线，不经过 LLM。

| sub_type | 示例 | target |
|----------|------|--------|
| `product_list` | "最近有什么新上架的产品" | `skill:query_products` |
| `product_detail` | "R2理财产品的收益率" | `skill:query_products` |
| `cust_detail` | "王建国 AUM 多少" | `skill:query_customers` |
| `cust_holdings` | "王建国持有哪些产品" | `skill:query_holdings` |
| `opp_progress` | "王建国的商机推进情况" | `skill:query_opportunities` |
| `task_count` | "今天有多少待办" | `skill:query_tasks` |
| `task_list` | "今天有哪些待办" | `skill:query_tasks` |
| `kpi_snapshot` | "本月存款完成率" | `skill:query_performance` |
| `expiring_alert` | "哪些客户产品快到期了" | `skill:scan_expiring` |

#### B. knowledge_qa — 知识问答

用户问"是什么/为什么/怎么选"，需要 RAG 检索 + LLM 推理。

| sub_type | 示例 | target |
|----------|------|--------|
| `product_explain` | "结构性存款是什么" | `agent:qa_assistant` |
| `product_compare` | "大额存单和定期有什么区别" | `agent:qa_assistant` |
| `business_qa` | "个人住房贷款需要什么材料" | `agent:qa_assistant` |
| `compliance_qa` | "能不能免面签" | `agent:qa_assistant` |
| `allocation_advice` | "50万闲置半年怎么配置" | `agent:qa_assistant` |
| `general_qa` | 通用业务问题 | `agent:qa_assistant` |

#### C. action — 行动执行

用户要求执行某个具体操作，对应已有 Agent 能力。

| sub_type | 示例 | target | 已有静态路由 |
|----------|------|--------|:---:|
| `opp_mining` | "帮我挖掘商机" | `agent:opp_mining` | ✅ |
| `battle_gen` | "给王建国生成作战包" | `agent:battle_pkg` | ✅ |
| `insight_gen` | "分析王建国的客户画像" | `agent:customer_insight` | ✅ |
| `schedule_adj` | "帮我重新排一下今天的日程" | `agent:scheduler` | ✅ |
| `content_gen` | "生成今天的工作总结" | `agent:content_gen` | ✅ |

#### D. complex — 复合意图

用户一个问题涉及多个 Agent 能力。

| sub_type | 示例 | target |
|----------|------|--------|
| `cust_full_analysis` | "全面分析王建国并给出营销建议" | `customer_insight` + `opp_mining` + `battle_pkg` |
| `daily_briefing` | "今天最需要关注什么" | `scheduler` + `content_gen` + `opp_mining` |
| `pre_meeting_prep` | "明天面谈王建国帮我准备一下" | `customer_insight` + `battle_pkg` + `scheduler` |

#### E. ambiguous — 意图模糊

无法判断用户意图，需要追问或降级处理。

### 3.3 意图识别策略

```
classify_intent(question, context):
    │
    ├── Layer 1: 规则前缀匹配（零延迟）
    │     匹配明确的指令式表达：
    │     "帮我挖掘商机" → action.opp_mining
    │     "生成作战包"   → action.battle_gen
    │     "查一下"       → data_query
    │     "什么是"       → knowledge_qa
    │
    ├── Layer 2: 实体识别 + 上下文推断（无 LLM）
    │     用户提到了客户名 + "商机" → data_query.opp_progress
    │     用户提到了产品名 + 问句特征 → knowledge_qa.product_explain
    │
    └── Layer 3: LLM-based 分类（兜底，仅在前两层无法确定时）
          轻量 prompt，专注分类而非生成：
          "将以下用户输入归类为: data_query | knowledge_qa | action | complex | ambiguous
           输入: {question}
           上下文: {context_summary}
           仅输出类别和 sub_type，不要解释。"
```

**性能目标**：Layer 1+2 覆盖 80%+ 场景，Layer 3 仅处理长尾模糊输入。

---

## 四、分发调度逻辑

### 4.1 dispatch() 决策树

```python
async def dispatch(intent_result, ctx):
    """
    根据意图分类结果执行调度决策

    Returns:
        { response, suggestions }
    """
    # ── 分支 1: 数据查询 → 直接走 Skill ──
    if intent_result.intent_category == "data_query":
        data = await harness.skills.execute(
            intent_result.target,  # e.g. "query_products"
            filters=intent_result.entities,
            ctx=ctx,
        )
        response = format_data_response(data, intent_result.sub_type)
        suggestions = suggestion_engine.generate(intent_result.sub_type, ctx)
        return { "response": response, "suggestions": suggestions }

    # ── 分支 2: 静态路由命中 + 高置信度 → 给出跳转链接 ──
    if (intent_result.matched_static_route
        and intent_result.route_confidence > 0.75
        and intent_result.agent_count == 1):

        response = {
            "type": "navigate",
            "message": f"💡 您可以通过「{intent_result.sub_type}」功能快速处理",
            "link": intent_result.matched_static_route,
            "label": "点击跳转",
        }
        return { "response": response, "suggestions": [] }

    # ── 分支 3: 单 Agent → 直接调用 ──
    if intent_result.agent_count == 1:
        agent_result = await harness.invoke(
            intent_result.target.replace("agent:", ""),
            method=get_default_method(intent_result.sub_type),
            ctx=ctx,
            **intent_result.entities,
        )
        suggestions = suggestion_engine.generate(
            f"{intent_result.sub_type}_done", ctx, agent_result
        )
        return { "response": agent_result, "suggestions": suggestions }

    # ── 分支 4: 多 Agent → 并行调用 + 合并 ──
    if intent_result.agent_count > 1:
        tasks = []
        for target in intent_result.targets:
            tasks.append(harness.invoke(target, ..., ctx=ctx))
        results = await asyncio.gather(*tasks)
        response = merge_responses(results, intent_result.sub_type)
        suggestions = suggestion_engine.generate(
            f"{intent_result.sub_type}_done", ctx
        )
        return { "response": response, "suggestions": suggestions }

    # ── 分支 5: 无法识别 → fallback ──
    response = await self.fallback(intent_result, ctx)
    suggestions = suggestion_engine.generate("fallback", ctx)
    return { "response": response, "suggestions": suggestions }
```

### 4.2 决策流程图

```
RouterAgent.dispatch(intent_result, ctx)
              │
    ┌─────────┼─────────┬─────────────┬──────────┐
    ▼         ▼         ▼             ▼          ▼
data_query  navigate  single_agent  multi_agent  fallback
    │         │         │             │          │
    ▼         ▼         ▼             ▼          ▼
Skill.    返回跳转   harness.     parallel    追问/
execute   链接+文案  invoke      invoke+     引导
    │                   │        merge         │
    ▼                   ▼          ▼           ▼
格式化     (结束)     Agent    合并响应    建议生成
数据                  结果
    │                   │
    ▼                   ▼
建议生成              建议生成
```

### 4.3 多 Agent 并行调用

```
用户: "明天面谈王建国帮我准备一下"
        │
        ▼
RouterAgent.classify_intent()
  → intent_category: "complex"
  → sub_type: "pre_meeting_prep"
  → targets: ["customer_insight", "battle_pkg", "scheduler"]
  → agent_count: 3
        │
        ├── harness.invoke("customer_insight", "generate", cust_id="cust_001")
        ├── harness.invoke("battle_pkg", "gen_battle_package", cust_id="cust_001")
        └── harness.invoke("scheduler", "optimize_schedule", date="tomorrow")
        │
        ▼ (并行执行，等待全部完成)
merge_responses(results):
  ① 客户洞察 → 风险信号 + AUM 变化
  ② 作战包   → 面谈话术 + 产品推荐
  ③ 日程     → 确认明天上午 10:00 面谈
        │
        ▼
统一输出:
  "已为您准备好明天的面谈资料：
   📊 客户洞察：AUM 近30天下降15%，有2个到期产品
   📋 作战包：已生成包含话术和产品推荐 [查看作战包]
   📅 日程：明天 10:00-11:00 面谈已确认"
```

---

## 五、建议生成引擎

### 5.1 设计原则

- **由 RouterAgent 统一生成**，不由各 Agent 独立输出
- **规则引擎优先**，覆盖 85%+ 场景，LLM 仅兜底
- **1-3 条 / 轮**，避免信息过载
- **去重**：同一路由只保留最高优先级
- **优先级**：1=必须关注，2=高价值，3=锦上添花

### 5.2 建议规则表（按意图类别）

#### data_query — 查完后下一步

| 条件 | 建议 | 路由 | 优先级 |
|------|------|------|:---:|
| 查询结果为空 | "未找到匹配结果，试试 [放宽条件]" | AI 对话 | 1 |
| 查产品且存在到期持有客户 | "有 {n} 位客户持有该产品且即将到期，[查看到期客户]" | `/products/expiring` | 2 |
| 查客户且有未处理商机 | "{name} 有 {n} 个进行中商机，[查看商机]" | `/opportunity?cust={id}` | 1 |
| 查客户且有大额异动 | "{name} 近7天有资金变动，[查看流水]" | `/customer/{id}/fund-flow` | 1 |
| 查客户且有到期产品 | "{name} 的 {product} {n}天后到期，[查看到期]" | `/products/expiring` | 2 |
| 查客户且超14天未联系 | "{name} 已 {n}天未联系，[添加日程]" | `/schedule/today` | 3 |
| 查客户且有已有作战包 | "已为该客户生成过作战包，[查看]" | `/battle?cust={id}` | 4 |
| 查商机且未生成作战包 | "为该商机生成作战包，[立即生成]" | `agent:battle_pkg` | 2 |
| 查商机且状态长期未更新 | "该商机 {n}天未更新状态，[更新]" | `/opportunity/{id}/update` | 3 |
| 查待办且有高优未处理 | "今日还有 {n} 项高优待办未开始，[查看日程]" | `/schedule/today` | 1 |
| 查待办且下午有空闲 | "下午 {time}后有 {n}小时空闲，[添加任务]" | `/schedule/today` | 3 |
| 查KPI且有指标落后 | "{kpi}完成 {pct}%，落后进度 {gap}%，[追赶策略]" | `agent:insight` | 1 |

#### knowledge_qa — 答完后落地

| 条件 | 建议 | 路由 | 优先级 |
|------|------|------|:---:|
| 解读的产品有客户持有 | "您的 {n} 位客户持有该产品，[查看持有客户]" | `/products/{id}/holders` | 1 |
| 有相似产品可对比 | "相似产品 {product} 收益高 {diff}%，[对比]" | `/products/compare` | 2 |
| 问答涉及办理材料 | "申请材料清单已整理，[生成办理清单]" | `skill:gen_checklist` | 1 |
| 流程含多环节 | "该流程含 {n} 个环节，[设日程提醒]" | `/schedule` | 2 |
| 有客户正在办理该业务 | "客户 {name} 正在该环节，[查看进度]" | `/customer/{id}/progress` | 3 |
| 配置建议且客户有预约 | "该客户 {date}有预约，[查看面谈日程]" | `/schedule` | 2 |
| 配置建议且风险评测过期 | "风险评测已过期，[发起评测]" | `/customer/{id}/risk` | 3 |
| 合规咨询被拦截但有替代方案 | "不能保本承诺，可推荐 R1 产品，[查看]" | `/products?risk=R1` | 1 |

#### action — 执行后闭环

| 条件 | 建议 | 路由 | 优先级 |
|------|------|------|:---:|
| 挖掘出新商机 | "新发现 {n} 个商机，[查看详情]" | `/opportunity` | 1 |
| 无新商机 | "暂无新商机，可 [重新挖掘] 或 [查看已有]" | AI / 页面 | 2 |
| 作战包生成完成 | "作战包已生成，[查看]" | `/battle/{bp_id}` | 1 |
| 作战包含话术 | "话术已就绪，[进入话术模式]" | `/battle/{bp_id}/scripts` | 2 |
| 洞察发现风险 | "⚠️ 发现 {n} 个风险信号，[查看]" | `/customer/{id}/insight` | 1 |
| 洞察发现商机线索 | "发现 {n} 条商机线索，[AI 挖掘]" | `agent:opp_mining` | 2 |
| 日程调整完成 | "今日日程已优化，预计节省 {n}分钟，[查看]" | `/schedule/today` | 1 |
| 有未排入待办 | "{n} 项待办未排入，[手动添加] 或 [延至明天]" | `/schedule` | 2 |

#### 时间情境感知

| 条件 | 建议 | 路由 | 优先级 |
|------|------|------|:---:|
| 上午 8:00-9:00 首次对话 | "早上好！[查看今日日程] 或 [听听 AI 摘要]" | `/schedule/today` | 1 |
| 上午有面谈预约 | "今天 {time} 约了 {name}，[查看作战包]" | `/battle?cust={id}` | 2 |
| 下午 17:00 后 | "今日工作即将结束，[查看回顾]" | `agent:content_gen` | 1 |
| 周五下午 | "本周回顾已生成，[查看周报] 或 [排下周]" | `/schedule` | 2 |
| 月末最后一天 | "本月业绩快照已更新，距目标差 {gap}%，[冲刺]" | `/kpi` | 1 |
| 周一上午 | "新的一周！[回顾上周] → [本周日程] → [积压待办]" | 引导链 | 2 |
| 节假日/休息日 | "有 {n} 项待办可提前准备，[查看]" | `/schedule` | 3 |

#### 通用 / fallback

| 条件 | 建议 | 路由 | 优先级 |
|------|------|------|:---:|
| 意图不明确 | "我没完全理解。试试：[今日待办] [商机] [到期提醒]" | AI 引导 | 1 |
| 连续 3 轮同类型查询 | "已连续查询 {n} 次，需要我 [升级服务] ？" | AI 升级 | 3 |
| 对话 > 5 轮 | "已连续对话 {n} 轮，需要 [生成总结] 或 [重新开始] ？" | AI 管理 | 5 |
| 任何场景（兜底） | "您今天还有 {n} 项待办，[查看日程]" | `/schedule/today` | 5 |

### 5.3 智能引导链

复杂场景下可生成 2-3 步串联建议：

| 链类型 | 触发条件 | 步骤模板 |
|--------|---------|---------|
| **客户经营链** | 客户有风险 + 商机 + 可行动 | 查看洞察 → 处理风险 → 挖掘商机 → 生成作战包 |
| **日程准备链** | 有面谈 + 无作战包 | 生成洞察 → 生成作战包 → 预览话术 → 确认日程 |
| **业绩冲刺链** | KPI 落后 + 有可转化商机 | 查看缺口 → 筛选商机 → 优先推进 → 更新预测 |
| **晨间启动链** | 上午首次对话 | AI 摘要 → 今日日程 → 待办优先级 → 开始执行 |
| **收尾回顾链** | 下午 17:00 后 | 今日小结 → 未完成待办 → 明日预排 → 结束 |

### 5.4 引擎实现

```python
class SuggestionEngine:
    """RouterAgent 内置建议引擎"""

    max_suggestions = 3
    min_suggestions = 1

    def generate(self, intent: str, ctx: SuggestionContext,
                 agent_result: dict = None) -> list[Suggestion]:
        """生成建议列表"""
        # 加载规则表
        rules = RULES.get(intent, []) + RULES.get("general", [])

        suggestions = []
        for condition_fn, template, route, priority in rules:
            if len(suggestions) >= self.max_suggestions:
                break
            if condition_fn(ctx):
                suggestions.append(Suggestion(
                    text=template.format(**ctx.to_dict()),
                    route=route,
                    priority=priority,
                ))

        # 去重 + 排序 + 截断
        suggestions = self._deduplicate(suggestions)
        suggestions.sort(key=lambda s: s.priority)

        # 不足时 LLM 兜底
        if len(suggestions) < self.min_suggestions:
            suggestions += self._llm_fallback(intent, ctx)

        return suggestions[:self.max_suggestions]
```

---

## 六、与 QAAgent 的能力边界

| 维度 | QAAgent | RouterAgent |
|------|---------|-------------|
| **定位** | 知识问答专家（RAG + LLM） | 对话调度中枢（意图识别 + 分发） |
| **负责的问题** | "结构性存款是什么"、"怎么申请贷款" | 判断问题属于哪个 Agent，分发执行 |
| **是否调 LLM** | 是（核心能力） | 仅在 LLM-based 意图识别和 fallback 建议时使用 |
| **输出** | 知识性回答（结构化 Markdown） | 分发决策 + 建议列表 |
| **调用关系** | 被 RouterAgent 调用的目标之一 | 调度者，决定是否调用 QAAgent |

### 关键区分

```
用户问 "有什么R2理财产品" ：
  ✅ QAAgent 路径（旧）：RAG 检索产品知识 → LLM 生成回答
  ❌ RouterAgent 路径（新）：识别为 data_query → skill:query_products 直接查库

用户问 "结构性存款和大额存单有什么区别" ：
  ❌ 数据查询不够用，需要推理对比
  ✅ RouterAgent → QAAgent（RAG + LLM 对比分析）

用户问 "王建国的商机推进情况" ：
  ❌ 不是知识问答，不需要 QAAgent
  ✅ RouterAgent → skill:query_opportunities（返回结构化数据）
     如果 confidence > 0.75：直接给出跳转链接
```

---

## 七、API 设计

### 7.1 统一对话入口

```
POST /api/ai/chat

Request:
{
  "question": "王建国最近怎么样",
  "manager_id": "M001",
  "history": [ ... ],           // 可选，对话历史
  "context": {                  // 可选，前端上下文
    "current_page": "workbench",
    "current_customer_id": null
  }
}

Response:
{
  "code": 0,
  "data": {
    "type": "data_query" | "agent_response" | "navigate" | "fallback",
    "content": { ... },          // 回答内容（根据 type 变化）
    "suggestions": [
      { "text": "王建国 AUM 下降 30%", "route": "/customer/cust_001/insight", "priority": 1 },
      { "text": "有 2 个产品下月到期", "route": "/products/expiring", "priority": 2 }
    ],
    "meta": {
      "intent": "cust_detail",
      "confidence": 0.94,
      "duration_ms": 320
    }
  }
}
```

### 7.2 保留的静态 API（不经 RouterAgent）

以下 API 保持不变，直接由前端场景入口调用：

| API | Agent | 前端触发 |
|-----|-------|---------|
| `POST /api/ai/opportunity/mining` | OppMiningAgent | 商机看板 "一键 AI 挖掘" |
| `POST /api/ai/battle-package/generate` | BattlePkgAgent | 客户/商机详情页 |
| `POST /api/ai/customer-insight/generate` | CustomerInsightAgent | 客户画像页 |
| `POST /api/ai/qa/ask` | QAAgent | 客户频道/产品频道 AI 入口 |

---

## 八、Agent 定义

### 8.1 元数据

```python
@agent(
    name="AI对话路由智能体",
    role="router",
    description="AI对话模式下的智能调度中枢：意图识别、Agent分发、Skill直接调用、响应合并与问答后建议生成",
    skills=[
        "classify_intent",       # 意图分类（规则 + LLM）
        "route_to_expert",       # 分发到领域 Agent
        "route_to_skill",        # 分发到数据 Skill
        "merge_responses",       # 多 Agent 响应合并
        "generate_suggestions",  # 问答后建议生成
        "fallback",              # 降级兜底
    ],
    triggers=["on_demand"],      # 对话模式按需触发
    rate_limit=200,              # 高频调用场景
    timeout=30,                  # 意图分类应极快
)
class RouterAgent(Agent):
    """AI 对话路由领域专家"""

    system_prompt = "prompts/router.md"
```

### 8.2 初始化

```python
# app.py 中的初始化
from agentos.agents.router import create_router_agent

router_agent = create_router_agent()
# → 自动注册到全局 harness
# → 加载 prompts/router.md
# → 初始化 SuggestionEngine (规则表)
# → 初始化 IntentClassifier (Layer 1 规则表)
```

---

## 九、实施路径

### Phase 1：基础框架（当前）

- [x] Harness 统一调用机制（`harness.invoke` / `harness.skills.execute`）
- [x] Agent 注册中心（`AgentRegistry`）
- [x] QAAgent 内部意图分类（规则匹配，作为参考实现）

### Phase 2：RouterAgent 核心（下一步）

- [ ] 创建 `agentos/agents/router.py` — RouterAgent 类
- [ ] 实现 `classify_intent()` — Layer 1 规则 + Layer 3 LLM 兜底
- [ ] 实现 `dispatch()` — 五大分支决策逻辑
- [ ] 新增 `POST /api/ai/chat` — 统一对话入口
- [ ] 前端 `AiChat.vue` 对接 `/api/ai/chat`

### Phase 3：建议引擎

- [ ] 实现 `SuggestionEngine` — 规则引擎
- [ ] 实现 `RULES` 规则表（本文档 §5.2 完整规则）
- [ ] 实现 LLM 兜底建议生成

### Phase 4：高级能力

- [ ] 多 Agent 并行调用 + 响应合并
- [ ] 智能引导链
- [ ] 实体解析增强（客户名 → cust_id）
- [ ] Layer 2 上下文推断（无需 LLM）

---

> **关联文档**：
> - 总体架构：[AgentOS总体架构](./00-AgentOS总体架构.md)
> - 智能体体系：[智能体体系总览](./01-智能体体系总览.md)
> - 运行时设计：[AgentOS运行时设计](../04-tech-design/01-AgentOS运行时设计.md)
> - 智能问答助手：[QAAgent设计](./07-智能问答助手.md)
